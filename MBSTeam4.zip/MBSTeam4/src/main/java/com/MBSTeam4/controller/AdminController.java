package com.MBSTeam4.controller;

import com.MBSTeam4.model.Database;
import com.MBSTeam4.model.Movie;
import com.MBSTeam4.model.Admin;
import jakarta.servlet.http.HttpSession;
import org.springframework.ui.Model;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/admin")
public class AdminController {
	@GetMapping("/home")
	public String homePage(Model model, HttpSession session) {
		String adminId = (String) session.getAttribute("adminId");
		
		if (adminId == null) {
	        return "redirect:/home";
	    } 
		else {
	        model.addAttribute("username", adminId);
	        model.addAttribute("movies", Database.movies);
	    }
		
	    return "admin-home"; 
	}
	
	@PostMapping("/add-movie")
	public String addMovie(@RequestParam String title, 
						   @RequestParam String director,
	                       @RequestParam String showtime, 
	                       @RequestParam String location,
	                       @RequestParam int movieId, 
	                       @RequestParam float avgReview, 
	                       @RequestParam float cost,
	                       Model model, HttpSession session) {

	    if (session.getAttribute("adminId") == null) {
	        return "redirect:/home";
	    }

	    Movie newMovie = new Movie(title, director, showtime, location, movieId, avgReview, cost);
	    Database.movies.add(newMovie);

	    model.addAttribute("success", "Movie added successful");
	    return "redirect:/admin/home";
	}
	
	@PostMapping("/delete-movie")
	public String deleteMovie(@RequestParam int movieId, HttpSession session) {
	    if (session.getAttribute("adminId") == null) {
	        return "redirect:/home";
	    }
	    Database.movies.removeIf(movie -> movie.getMovieId() == movieId);
	    return "redirect:/admin/home";
	}
	
	@GetMapping("/edit-movie")
	public String showEditForm(@RequestParam int movieId, Model model, HttpSession session) {
	    if (session.getAttribute("adminId") == null) {
	        return "redirect:/home";
	    }
	    for (Movie movie : Database.movies) {
	        if (movie.getMovieId() == movieId) {
	            model.addAttribute("movie", movie);
	            return "edit-movie";
	        }
	    }
	    return "redirect:/admin/home";
	}
	
	@PostMapping("/edit-movie")
	public String editMovie(@RequestParam String title,
	                        @RequestParam String director,
	                        @RequestParam String showtime,
	                        @RequestParam String location,
	                        @RequestParam int movieId,
	                        @RequestParam float avgReview,
	                        @RequestParam float cost,
	                        HttpSession session) {

	    if (session.getAttribute("adminId") == null) {
	        return "redirect:/home";
	    }

	    for (Movie movie : Database.movies) {
	        if (movie.getMovieId() == movieId) {
	            movie.setTitle(title);
	            movie.setDirector(director);
	            movie.setShowtime(showtime);
	            movie.setLocation(location);
	            movie.setAvgReview(avgReview);
	            movie.setCost(cost);
	            break;
	        }
	    }
	    return "redirect:/admin/home";
	}
}