package com.MBSTeam4.model;

import java.util.HashMap;
import java.util.Map;
import java.util.List;
import java.util.ArrayList;

public class Database {
    
    public static Map<String, Account> accounts = new HashMap<>();
    public static Map<String, Cart> carts = new HashMap<>();
    public static Map<String, List<Ticket>> tickets = new HashMap<>();
    public static Map<String, Admin> admins = new HashMap<>();
    public static List<Movie> movies = new ArrayList<>();
    public static List<String> locations = new ArrayList<>();
    
    static {
        Admin admin = new Admin();
        admin.setId("admin");
        admin.setPassword("admin123"); 
        admins.put(admin.getId(), admin);
    }
    
    static {
        movies.add(new Movie("Inception", "Nolan", "7:00PM", "Lubbock", 1001, 8.8f, 15.0f));
        movies.add(new Movie("The Matrix", "Wachowskis", "9:00PM", "Amarillo", 1002, 9.0f, 12.0f));
        movies.add(new Movie("Transformers 3", "Michael Bay", "10:00PM", "Levelland", 1003, 7.2f, 13.0f));
    }
    
    static {
        locations.add("Lubbock");
        locations.add("Amarillo");
        locations.add("Levelland");
        locations.add("Plainview");
        locations.add("Snyder");
        locations.add("Abilene");
    }
}
