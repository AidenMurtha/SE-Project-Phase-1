package com.MBSTeam4.controller;

import com.MBSTeam4.model.Database;
import com.MBSTeam4.model.Account;
import com.MBSTeam4.model.Cart;
import com.MBSTeam4.model.Movie;
import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import java.util.*;

@Controller
@RequestMapping("/account")
public class AccountController {

	@GetMapping("/home")
	public String homePage(@RequestParam(required = false) String query,
			               @RequestParam(required = false) String selectedLocation,
			               Model model, HttpSession session) {
	    String userId = (String) session.getAttribute("userId");
	    if (userId == null) {
	    	return "redirect:/home";
	    }
	    
	    Account user = Database.accounts.get(userId);
	    if (user == null) {
	        session.invalidate();
	        return "redirect:/home";
	    }
	    
	    String accountLocation = user.getLocation(); 
	    String location = (selectedLocation != null) ? selectedLocation : accountLocation;
	    
	    model.addAttribute("username", userId);
	    model.addAttribute("accountLocation", accountLocation);     
	    model.addAttribute("selectedLocation", location);   
	    model.addAttribute("locations", Database.locations);        
	    model.addAttribute("locationMismatch", !location.equals(accountLocation));
	    
	    //This part is for the search bar logic
	    if (query != null && !query.trim().isEmpty()) {
	        String lowerQuery = query.toLowerCase();
	        List<Movie> filtered = new ArrayList<>();

	        for (Movie movie : Database.movies) {
	        	
	            if (location.equals("All Locations") || movie.getLocation().equals(location) 
	            	&& movie.getTitle().toLowerCase().contains(lowerQuery)) {
	                filtered.add(movie);
	            }
	        }

	        for (int i = 0; i < filtered.size(); i++) {
	            for (int j = i + 1; j < filtered.size(); j++) {
	                Movie m1 = filtered.get(i);
	                Movie m2 = filtered.get(j);
	                int score1 = similarityScore(m1.getTitle(), lowerQuery);
	                int score2 = similarityScore(m2.getTitle(), lowerQuery);

	                if (score2 > score1) {
	                    Movie temp = filtered.get(i);
	                    filtered.set(i, filtered.get(j));
	                    filtered.set(j, temp);
	                }
	            }
	        }
	        model.addAttribute("movies", filtered);
	        model.addAttribute("query", query);
	    } 
	    else {
	    	List<Movie> notFiltered = new ArrayList<>();
	        for (Movie movie : Database.movies) {
	            if (location.equals("All Locations") || movie.getLocation().equals(location)) {
	                notFiltered.add(movie);
	            }
	        }
	        model.addAttribute("movies", notFiltered);
	    }

	    return "account-home";
	}
	
	private Movie findMovie(int movieId) {
        for (Movie m : Database.movies) {
        	
            if (m.getMovieId() == movieId) {
                return m;
            }
        }
        return null;
    }
	
	//This part checks the similarity of search result with the movie title
	private int similarityScore(String title, String query) {
	    title = title.toLowerCase();
	    int score = 0;
	    for (char c : query.toCharArray()) {
	        if (title.contains(String.valueOf(c))) score++;
	    }
	    return score;
	}

    @PostMapping("/add-to-cart")
    public String addToCart(@RequestParam int movieId,
            				@RequestParam(required = false) String location,
            				Model model, HttpSession session) {
        String userId = (String) session.getAttribute("userId");
        
        if (userId == null) {
        	return "redirect:/home";
        }
        
        Account user = Database.accounts.get(userId);
	    if (user == null) {
	        session.invalidate();
	        return "redirect:/home";
	    }
	    
	    String accountLocation = user.getLocation();
	    if (location == null || location.trim().isEmpty()) {
	        location = accountLocation;
	    }
        Cart cart = Database.carts.getOrDefault(userId, new Cart());
        cart.setAccountId(userId);

        Movie selectedMovie = findMovie(movieId);

        if (selectedMovie != null && selectedMovie.getLocation().equals(user.getLocation())) {
            Map<Integer, Integer> items = cart.getItems();
            items.put(movieId, items.getOrDefault(movieId, 0)+1);
            cart.setTotal(cart.getTotal() + selectedMovie.getCost());
            Database.carts.put(userId, cart);
            
            model.addAttribute("addedMessage", "Added to cart");
            model.addAttribute("addedMovieId", movieId);
        }
        
        List<Movie> filtered = new ArrayList<>();
        for (Movie movie : Database.movies) {
            if (movie.getLocation().equals(location)) {
                filtered.add(movie);
            }
        }
        
        model.addAttribute("movies", filtered);
        model.addAttribute("username", userId);
        model.addAttribute("accountLocation", accountLocation);
        model.addAttribute("selectedLocation", location);  
        model.addAttribute("locations", Database.locations);
        model.addAttribute("locationMismatch", !location.equals(accountLocation));

        return "account-home";
    }

    @PostMapping("/cart/increase")
    public String increaseQuantity(@RequestParam int movieId, HttpSession session) {
    	String userId = (String) session.getAttribute("userId");
   
        if (userId == null) {
        	return "redirect:/home";
        }

        Cart cart = Database.carts.get(userId);
        
        if (cart != null && cart.getItems().containsKey(movieId)) {
            cart.getItems().put(movieId, cart.getItems().get(movieId) + 1);
            Movie movie = findMovie(movieId);
            
            if (movie != null) {
            	cart.setTotal(cart.getTotal() + movie.getCost());
            }
        }
        return "redirect:/account/cart";
    }

    @PostMapping("/cart/decrease")
    public String decreaseQuantity(@RequestParam int movieId, HttpSession session) {
    	String userId = (String) session.getAttribute("userId");
        
    	if (userId == null) {
        	return "redirect:/home";
        }

        Cart cart = Database.carts.get(userId);
        
        if (cart != null && cart.getItems().containsKey(movieId)) {
            int currentQty = cart.getItems().get(movieId);
            Movie movie = findMovie(movieId);
            
            if (movie != null) {
            	cart.setTotal(cart.getTotal() - movie.getCost());
            }

            if (currentQty > 1) {
                cart.getItems().put(movieId, currentQty - 1);
            } 
            else {
                cart.getItems().remove(movieId);
            }
        }
        return "redirect:/account/cart";
    }

    @GetMapping("/cart")
    public String viewCart(Model model, HttpSession session) {
        String userId = (String) session.getAttribute("userId");
        
        if (userId == null) {
        	return "redirect:/home";
        }

        Cart cart = Database.carts.getOrDefault(userId, new Cart());

        Map<Movie, Integer> movieQuantityMap = new LinkedHashMap<>();
        
        for (Map.Entry<Integer, Integer> entry : cart.getItems().entrySet()) {
            int movieId = entry.getKey();
            int qty = entry.getValue();
            Movie movie = findMovie(movieId);
            
            if (movie != null) {
                movieQuantityMap.put(movie, qty);
            }
        }

        model.addAttribute("movieQuantities", movieQuantityMap); 
        model.addAttribute("cart", cart);
        model.addAttribute("username", userId);
        return "cart";
    }

    @PostMapping("/empty-cart")
    public String emptyCart(HttpSession session) {
        String userId = (String) session.getAttribute("userId");
        
        if (userId == null) {
        	return "redirect:/home";
        }

        Cart cart = Database.carts.get(userId);
        
        if (cart != null) {
            cart.setItems(new HashMap<>());
            cart.setTotal(0);
        }
        return "redirect:/account/cart";
    }
    
    @GetMapping("/info")
    public String viewAccountInfo(HttpSession session, Model model) {
        
    	String userId = (String) session.getAttribute("userId");
        if (userId == null) {
        	return "redirect:/home";
        }

        Account account = Database.accounts.get(userId);
        if (account == null) {
        	session.invalidate();
        	return "redirect:/home";
        }

        model.addAttribute("username", userId);
        model.addAttribute("account", account);
        
        return "account-info";
    }

    @PostMapping("/payment")
    public String makePayment(HttpSession session) {
        String userId = (String) session.getAttribute("userId");
        
        if (userId == null) {
        	return "redirect:/home";
        }
        // this part is not done yet
        return "redirect:/account/cart";
    }
    
    @GetMapping("/edit-info")
    public String editAccountInfo(HttpSession session, Model model) {
        String userId = (String) session.getAttribute("userId");
        if (userId == null) {
            return "redirect:/home";
        }

        Account account = Database.accounts.get(userId);
        if (account == null) {
        	session.invalidate();
            return "redirect:/home";
        }

        model.addAttribute("username", userId);
        model.addAttribute("account", account);
        model.addAttribute("locations", Database.locations);

        return "account-edit-info"; 
    }
    
    @PostMapping("/edit-info")
    public String saveAccountInfo(@RequestParam String username,
                                   @RequestParam String email,
                                   @RequestParam String phone,
                                   @RequestParam String location,
                                   HttpSession session) {
        String userId = (String) session.getAttribute("userId");
        if (userId == null) {
            return "redirect:/home";
        }

        Account account = Database.accounts.get(userId);
        if (account == null) {
        	session.invalidate();
            return "redirect:/home";
        }

        account.setUsername(username);
        account.setEmail(email);
        account.setPhone(Long.parseLong(phone.replaceAll("[^0-9]", "")));
        account.setLocation(location);

        Database.saveAccounts(); 

        return "redirect:/account/edit-info?success=true"; 
    }

    @PostMapping("/delete")
    public String deleteAccount(HttpSession session) {
        String userId = (String) session.getAttribute("userId");

        if (userId != null) {
            Database.accounts.remove(userId); 
            Database.saveAccounts();          
            Database.carts.remove(userId);     
            Database.saveCarts();              
            session.invalidate();              
        }

        return "redirect:/home"; 
    }
    
    @PostMapping("/payment-method")
    public String choosePaymentMethod() {
        return "payment-method"; // shows payment-method.html
    }

    @PostMapping("/process-creditcard")
    public String paymentForm() {
        return "credit-card"; // shows credit-card.html
    }

    @PostMapping("/paypal")
    public String paypalForm() {
        return "paypal"; // shows paypal.html
    }

    @PostMapping("/venmo")
    public String venmoForm(@RequestParam(value = "venmoUsername", required = false) String venmoUsername) {
        if (venmoUsername != null) {
            System.out.println("Received Venmo username: " + venmoUsername);
            // handle payment here later
        }
        return "venmo"; // shows venmo.html
    }
    
    @PostMapping("/paymentconfirm")
    public String payconf() {
        return "pay-confirm"; // shows paypal.html
    }
    
    @PostMapping("/viewTickets")
    public String viewTickets() {
        return "viewTickets"; 
    }
}