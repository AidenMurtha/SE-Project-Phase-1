package com.MBSTeam4.model;

import java.io.Serializable;

public class Movie implements Serializable {
	private static final long serialVersionUID = 1L;
	
    private String title;
    private String director;
    private String showtime;
    private String location;
    private String imgUrl;
    private int movieId;
    private float avgReview;
    private float cost;
    
    public Movie() {
    }
    
    public Movie(String title, String director, String showtime, String location, String imgUrl, int movieId, float avgReview, float cost) {
        this.title = title;
        this.director = director;
        this.showtime = showtime;
        this.location = location;
        this.imgUrl = imgUrl;
        this.movieId = movieId;
        this.avgReview = avgReview;
        this.cost = cost;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDirector() {
        return director;
    }

    public void setDirector(String director) {
        this.director = director;
    }

    public String getShowtime() {
        return showtime;
    }

    public void setShowtime(String showtime) {
        this.showtime = showtime;
    }

    public int getMovieId() {
        return movieId;
    }

    public void setMovieId(int movieId) {
        this.movieId = movieId;
    }

    public float getAvgReview() {
        return avgReview;
    }

    public void setAvgReview(float avgReview) {
        this.avgReview = avgReview;
    }

    public float getCost() {
        return cost;
    }

    public void setCost(float cost) {
        this.cost = cost;
    }
    
    public String getLocation() { 
    	return location; 
    }
    
    public void setLocation(String location) { 
    	this.location = location; 
    }
    
    public String getImgUrl() { 
    	return imgUrl; 
    }
    
    public void setImgUrl(String imgUrl) { 
    	this.imgUrl = imgUrl; 
    }
}
