package com.MBSTeam4.model;

public class Ticket {
	private int code;
	private boolean validity;
	private String accountId;
	private String showtime;
	
	public int getCode() {
        return code;
    }
    
    public String getAccountId() {
        return accountId;
    }
    
    public boolean getValidity() {
        return validity;
    }
    
    public String getShowtime() {
        return showtime;
    }
	
    public void setCode(int code) {
        this.code = code;
    }
    
    public void setValidity(boolean validity) {
        this.validity = validity;
    }
    
    public void setAccountId(String id) {
        this.accountId = id;
    }
    
    public void setShowtime(String showtime) {
        this.showtime = showtime;
    }
}
