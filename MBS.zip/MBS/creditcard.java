package MBS;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class creditcard extends JFrame {

    JTextField CCN;
    JTextField zip;
    JTextField expiration;
    JTextField name;
    JTextField CVV;
    JPanel panel = new JPanel(new GridLayout(25, 2));

    public creditcard(Account account, JFrame parent, Cart cart) {
    	
    	//create window
        setTitle("Please enter payment details");
        setSize(500, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        //create center panel
        panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        JScrollPane scrollPane = new JScrollPane(panel);
        add(scrollPane, BorderLayout.CENTER);

        //create and add fields for credit card
        panel.add(new JLabel("Full Name:"));
        name = new JTextField();
        panel.add(name);

        panel.add(new JLabel("Credit Card Number:"));
        CCN = new JTextField();
        panel.add(CCN);

        panel.add(new JLabel("CVV:"));
        CVV = new JTextField();
        panel.add(CVV);

        panel.add(new JLabel("Zipcode:"));
        zip = new JTextField();
        panel.add(zip);

        panel.add(new JLabel("Expiration Date:"));
        expiration = new JTextField();
        panel.add(expiration);

        //add back button and event listener
        JButton backBtn = new JButton("Back");
        backBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
                parent.setVisible(true);
            }
        });
        //add submit button and event listener
        JButton submit = new JButton("Submit Payment");
        submit.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String fullName = name.getText();
                String creditCardNumber = CCN.getText();
                String cvv = CVV.getText();
                String zipCode = zip.getText();
                String expirationDate = expiration.getText();

                boolean paymentSuccess = true; // assumes payment success
                //if we were going to validate payment this is how
                
                if (paymentSuccess) {
                	account.addTicket(cart);//add tickets to account
                    cart.processPayment();  // clear cart

                    // payment success 
                    JOptionPane.showMessageDialog(creditcard.this, "Payment successful! Your tickets are now confirmed.");

                    dispose();
                    new paymentcomplete(account, parent, cart);//payment complete screen
                } else {
                    // payment failed 
                    JOptionPane.showMessageDialog(creditcard.this, "Payment failed! Please try again.");
                }
            }
        });
        //create bottom panel and add buttons
        JPanel botpan = new JPanel();
        botpan.add(backBtn);
        botpan.add(submit);
        add(botpan, BorderLayout.SOUTH);

        revalidate();
        repaint();
        setVisible(true);
    }
}
