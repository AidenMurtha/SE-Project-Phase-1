package MBS;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class venmo extends JFrame {

    JTextField email;
    JTextField user;

    JPanel panel = new JPanel(new GridLayout(25, 2));

    public venmo(Account account, JFrame parent, Cart cart) {
    	//create window

        setTitle("Please enter payment details");
        setSize(500, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        JScrollPane scrollPane = new JScrollPane(panel);
        add(scrollPane, BorderLayout.CENTER);

        //create fields and add to panel
        panel.add(new JLabel("Venmo account email:"));
        email = new JTextField();
        panel.add(email);

        panel.add(new JLabel("Venmo account username:"));
        user = new JTextField();
        panel.add(user);


        //add back button and action listener
        JButton backBtn = new JButton("Return to cart");
        backBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
                parent.setVisible(true);
            }
        });
        //add back submit and action listener
        JButton submit = new JButton("Submit Payment");
        submit.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                

                boolean paymentSuccess = true;// assumes payment success
                //if we were going to validate payment this is how

                if (paymentSuccess) {// payment success 
                	account.addTicket(cart);//add tickets to account
                    cart.processPayment();  //clear cart
                    JOptionPane.showMessageDialog(venmo.this, "Payment successful! Your tickets are now confirmed.");
                    dispose();
                    new paymentcomplete(account, parent, cart);
                } else {// payment fail 
                    JOptionPane.showMessageDialog(venmo.this, "Payment failed! Please try again.");
                }
            }
        });
        //create bottom panel and add buttons
        JPanel botpan = new JPanel();
        botpan.add(backBtn);
        botpan.add(submit);
        add(botpan, BorderLayout.SOUTH);

        revalidate();
        repaint();
        setVisible(true);
    }
}
