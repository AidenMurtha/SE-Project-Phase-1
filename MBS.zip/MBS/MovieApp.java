package MBS;

import javax.swing.*;

import java.awt.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import javax.swing.border.EmptyBorder;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.*;



public class MovieApp {
	 public static void main(String[] args) {
	     try {
	         for (UIManager.LookAndFeelInfo info : UIManager.getInstalledLookAndFeels()) {
	             if ("Nimbus".equals(info.getName())) {
	                 UIManager.setLookAndFeel(info.getClassName());
	                 break;
	             }
	         }
	     } catch (Exception e) {
	         // fallback
	     }
	     SwingUtilities.invokeLater(LoginScreen::new);
	 }
	}

class Database {
	 static List<Movie> movies = new ArrayList<>();
	 static Map<String, Cart> carts = new HashMap<>();
	 public static HashMap<String, Account> accounts = new HashMap<>();

	 static {
		 String def = ("7:00PM,9:30PM");//default movie times
		 //add default movies
	     movies.add(new Movie("Inception", "Nolan", 1900,8.8f, 15.0f, true, def,def,def,def,def,def));
	     movies.add(new Movie("The Matrix", "Wachowskis", 1901, 9.0f, 12.0f,true,def,def,def,def,def,def));
	     movies.add(new Movie("Spider-Man 4", "Jon Watts", 1904, 0.0f, 0.0f,false,def,def,def,def,def,def));
	     movies.add(new Movie("Thunderbolts", "Jake Schreier", 1905, 0.0f, 0.0f,false,def,def,def,def,def,def));
	     movies.add(new Movie("Fantastic Four", "Matt Shakman", 1907, 0.0f, 0.0f,false,def,def,def,def,def,def));;
	     movies.add(new Movie("Blade", "Yann Demange", 1908, 0.0f, 0.0f,false,def,def,def,def,def,def));
	 }
	}




class Cart {
    String accountEmail;
    List<MovieTicket> items = new ArrayList<>();

    public Cart(String email) {
        this.accountEmail = email;
    }

    public void addToCart(Movie movie, String showtime, String location, int quantity) {
        MovieTicket ticket = new MovieTicket(movie, showtime, location, quantity, movie.cost);
        items.add(ticket);
    }

    public float getTotal() {
        return (float) items.stream().mapToDouble(t -> t.movie.cost).sum();
    }

    public void clear() {
        items.clear();
    }

    public void removeTicket(MovieTicket ticket) {
        items.remove(ticket);
    }

    // Process payment and safely remove items from the cart after processing
    public void processPayment() {
        Iterator<MovieTicket> iterator = items.iterator();

        while (iterator.hasNext()) {
            MovieTicket ticket = iterator.next();
            
            // Here, we simulate ticket processing (e.g., saving data, printing info)
            System.out.println("Processing ticket for " + ticket.getMovieTitle() + " (" + ticket.getQuantity() + " tickets)");
            
            // Remove items from cart
            iterator.remove();  
        }

    }
}


class Movie {
	 String title, director;
	 int movieId;
	 float avgReview, cost;
	 boolean current;
	 String ashowtimes;
	 String lshowtimes;
	 String leashowtimes;
	 String pshowtimes;
	 String sshowtimes;
	 String abshowtimes;
	 
	 public boolean isCurrent() {
		    return current;
		}

	 public Movie(String title, String director, int movieId, float avgReview, float cost,boolean current, 
			 String ashowtimes, String lshowtimes, 	 String leashowtimes, String pshowtimes, String sshowtimes, String abshowtimes
 ) {
	     this.title = title;
	     this.director = director;
	     this.movieId = movieId;
	     this.avgReview = avgReview;
	     this.cost = cost;
	     this.current=current;
	     this.ashowtimes=ashowtimes;
	     this.lshowtimes=lshowtimes;
	     this.leashowtimes=leashowtimes;
	     this.pshowtimes=pshowtimes;
	     this.sshowtimes=sshowtimes;
	     this.abshowtimes=abshowtimes;

	 }


	public String getMovieInfo() {
		 	
	        StringBuilder info = new StringBuilder();
	        info.append("Title: ").append(title).append("\n");
	        info.append("Director: ").append(director).append("\n");
	        info.append("Movie ID: ").append(movieId).append("\n");
	        info.append("Average Review: ").append(avgReview).append("/5.0\n");
	        info.append("Ticket Cost: $").append(cost).append("\n");
	        return info.toString();
	    }


	public String toString() {return title + " — " + director + (avgReview > 0 ? " | Rating: " + avgReview : " (Coming Soon)");}
	public String getTitle(Movie movie) {return movie.title;}
	public int getId(Movie movie) {return movie.movieId;}
	public float getCost(Movie movie) {return movie.cost;}
	}



class Admin {
    static String adminUser = "admin";
    static String adminPass = "admin123";
    public static boolean login(String user, String pass) {return user.equals(adminUser) && pass.equals(adminPass);}
    public static void addMovie(Movie m) {Database.movies.add(m);}
    public static void deleteMovie(Movie m) {Database.movies.remove(m);}
}




class BrowseMenu extends JFrame {
    public BrowseMenu(Account account, JFrame parent) {
        setTitle("Browse Options");
        setSize(300, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new GridLayout(7, 1, 10, 10)); // Adjusted grid to fit all buttons

        // Create common buttons
        JButton browseBtn = new JButton("Browse All Movies");
        JButton searchBtn = new JButton("Search Movies");
        JButton comingSoonBtn = new JButton("Future Movies");
        JButton cartBtn = new JButton("View Cart");
        JButton logoutBtn = new JButton("Logout");
        JButton viewti = new JButton("View Tickets");


        if ("admin".equals(account.getType())) {
            JButton adminPage = new JButton("Administrative Options");
            adminPage.addActionListener(e -> {
                new adminpage(account);  
                dispose();
            });
            add(adminPage); 
        }

        // Add action listeners for other buttons
        browseBtn.addActionListener(e -> {
            setVisible(false);
            new MainScreen(account, this); // Go to movie screen
        });

        viewti.addActionListener(e -> {
            setVisible(false);
            new ticketscreen(account, this); // go to ticket screen
        });

        searchBtn.addActionListener(e -> {
            String query = JOptionPane.showInputDialog(this, "Enter movie title to search:");
            if (query != null && !query.trim().isEmpty()) {
                List<Movie> results = new ArrayList<>();
                for (Movie m : Database.movies) {
                    if (m.getTitle(m).toLowerCase().contains(query.toLowerCase())) {
                        results.add(m);
                    }
                }
                if (results.isEmpty()) {
                    JOptionPane.showMessageDialog(this, "No results found.");
                } else {
                    setVisible(false);
                    new SearchResultsScreen(account, results, this); // Show search results
                }
            }
        });

        comingSoonBtn.addActionListener(e -> {
            setVisible(false);
            new comingSoon(account, this); // Go to future movie screen
        });

        cartBtn.addActionListener(e -> {
            setVisible(false);
            new CartScreen(account, this); // Go to cart screen
        });

        logoutBtn.addActionListener(e -> {
            dispose();
            new LoginScreen(); // Go back to the login screen
        });

        // Add buttons to the layout
        add(browseBtn);
        add(searchBtn);
        add(comingSoonBtn);
        add(cartBtn);
        add(viewti);
        add(logoutBtn);

        //make  window visible
        setVisible(true);
    }
}


class MainScreen extends JFrame {
    protected JPanel moviePanel;

    public MainScreen(Account account, JFrame parent) {
        setTitle("Available Movies");
        setSize(600, 800);  // Bigger window for bigger posters
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        moviePanel = new JPanel();
        moviePanel.setLayout(new BoxLayout(moviePanel, BoxLayout.Y_AXIS));
        JScrollPane scrollPane = new JScrollPane(moviePanel);
        add(scrollPane, BorderLayout.CENTER);

        // Load all current movies from the Database
        for (Movie m : Database.movies) {
            if (m.isCurrent()) { // Only show movies that are currently playing
                MovieScreenPanel mPanel = new MovieScreenPanel(m.title); // You might want to update MovieScreenPanel later to take full Movie object if needed!

                // Clicking a movie opens its page
                mPanel.addMouseListener(new java.awt.event.MouseAdapter() {
                    @Override
                    public void mouseClicked(java.awt.event.MouseEvent evt) {
                        setVisible(false);
                        new moviePage(account, MainScreen.this, m);
                    }
                });

                moviePanel.add(mPanel);
                moviePanel.add(Box.createRigidArea(new Dimension(0, 30))); // Space between posters
            }
        }

        // Back button to return to parent screen
        JPanel bottomPanel = new JPanel();
        JButton backBtn = new JButton("Back");
        backBtn.addActionListener(e -> {
            dispose();
            if (parent != null) {
                parent.setVisible(true);
            }
        });
        bottomPanel.add(backBtn);
        add(bottomPanel, BorderLayout.SOUTH);

        setVisible(true);
    }
}


class MovieScreenPanel extends JPanel {
    String title;

    public MovieScreenPanel(String title) {
        this.title = title;
        setPreferredSize(new Dimension(300, 450)); // Poster size: Width 300px, Height 450px
        setMaximumSize(new Dimension(300, 450));
        setBackground(Color.WHITE);
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        // Draw poster frame
        g.setColor(Color.BLACK);
        g.drawRoundRect(10, 10, getWidth() - 20, getHeight() - 20, 30, 30);

        // Title text inside the poster
        g.setFont(new Font("SansSerif", Font.BOLD, 18));
        FontMetrics fm = g.getFontMetrics();
        int titleWidth = fm.stringWidth(title);
        int x = (getWidth() - titleWidth) / 2;
        int y = getHeight() - 40; // Put the title near the bottom
        g.drawString(title, x, y);
    }
}
class SearchResultsScreen extends MainScreen {
	 public SearchResultsScreen(Account account, List<Movie> searchResults, JFrame parent) {
	     super(account, parent);
	     moviePanel.removeAll();
	     for (Movie m : searchResults) {
	    	    JPanel mPanel = new JPanel();
	    	    mPanel.setLayout(new BoxLayout(mPanel, BoxLayout.Y_AXIS));
	    	    String title = m.getTitle(m);
	    	    JButton movieButton = new JButton(title);
	    	    movieButton.addActionListener(e -> {
	    	        dispose();
	    	        new moviePage(account, parent, m);
	    	    });
	    	    mPanel.add(movieButton); // Add the button to the panel

	    	    moviePanel.add(mPanel); 
	    	}

	 }
	}
        
        
        


class CartScreen extends JFrame {
    public CartScreen(Account account, JFrame parent) {
        setTitle("Your Cart");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        Cart cart = account.getCart();

        JTextArea cartArea = new JTextArea();
        cartArea.setEditable(false);
        if (cart.items.isEmpty()) {
            cartArea.setText("Your cart is empty.");
        } else {
            StringBuilder sb = new StringBuilder();
            for (MovieTicket ticket : cart.items) {
                sb.append(ticket).append("\n");
            }
            sb.append("\nTotal: $").append(String.format("%.2f", cart.getTotal()));
            cartArea.setText(sb.toString());
        }

        JScrollPane scrollPane = new JScrollPane(cartArea);
        add(scrollPane, BorderLayout.CENTER);

        JPanel buttonPanel = new JPanel(new GridLayout(2, 2, 10, 10));
        JButton payCard = new JButton("Pay with Card");
        JButton payVenmo = new JButton("Pay with Venmo");
        JButton payPayPal = new JButton("Pay with PayPal");
        JButton backBtn = new JButton("Back");

        payCard.addActionListener(e -> {
            new creditcard(account, parent, cart);  // Add payment window logic here
            dispose();
        });

        payVenmo.addActionListener(e -> {
            new venmo(account, parent, cart); // Add Venmo payment window logic
            dispose();
        });

        payPayPal.addActionListener(e -> {
            new paypall(account, parent, cart); // Add PayPal payment window logic
            dispose();
        });

        backBtn.addActionListener(e -> {
            dispose();
            parent.setVisible(true);
        });

        buttonPanel.add(payCard);
        buttonPanel.add(payVenmo);
        buttonPanel.add(payPayPal);
        buttonPanel.add(backBtn);
        add(buttonPanel, BorderLayout.SOUTH);

        setVisible(true);
    }

    private void processPayment(Account account, Cart cart) {
        // Create a list to store items to be removed after the loop
        List<MovieTicket> toRemove = new ArrayList<>();

        // Add each ticket to the tickets list of the account
        for (MovieTicket ticket : cart.items) {
            account.tickets.add(ticket); // Add to the account's tickets
            toRemove.add(ticket); // Also mark for removal from the cart
        }

        // Remove the items after the iteration is complete
        for (MovieTicket ticket : toRemove) {
            cart.removeTicket(ticket);
        }

    }


}





class adminpage extends JFrame {
    Account account;
    DefaultListModel<Movie> movieListModel = new DefaultListModel<>();
    JList<Movie> movieList;

    public adminpage(Account account) {
        this.account = account;

        setTitle("Administative Options");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);


        movieList = new JList<>(movieListModel);
        for (Movie m : Database.movies) {
            movieListModel.addElement(m);

        add(new JScrollPane(movieList), BorderLayout.CENTER);
        
        //create buttons and panel
        JPanel bottomPanel = new JPanel();
        JButton Home = new JButton("Home");
        JButton addmovie = new JButton("Add a Movie");
        JButton deleteMovie = new JButton("Remove a movie");
        
        //event handler
        Home.addActionListener(e -> { new BrowseMenu(account, null); dispose();});
        addmovie.addActionListener(e ->  {new addMovie(account); dispose(); });
        deleteMovie.addActionListener(e -> {
        	Movie selected = movieList.getSelectedValue();
            if (selected != null) {
                Database.movies.remove(selected);
                new adminpage(account);
                dispose();
                
            }
            });
        //but buttons on bottom panel
        bottomPanel.add(Home);
        bottomPanel.add(addmovie);
        bottomPanel.add(deleteMovie);
        add(bottomPanel, BorderLayout.SOUTH);

            }
        setVisible(true);
    }
}

class addMovie extends JFrame {
    Account account;
    DefaultListModel<Movie> movieListModel = new DefaultListModel<>();
    JList<Movie> movieList;
    JTextField title;
    JTextField director;
    JTextField cast;
    JTextField rating;
    boolean current;
    JTextField reviews;
    JTextField summary;
    JTextField runtime;
    JTextField price;
    JTextField movieid;
    JTextField time;
    JTextField ashowtimes;
    JTextField lshowtimes;
    JTextField leashowtimes;
    JTextField pshowtimes;
    JTextField sshowtimes;
    JTextField abshowtimes;




    public int getInt(JTextField field) {//method to get int from text field
	    return Integer.parseInt(field.getText());
	}
    public float getFloat(JTextField reviews) {//method to get float from text field
	    return Float.parseFloat(reviews.getText());
	}

    
    //add image somehow

    public addMovie(Account account) {
        this.account = account;

        setTitle("Please Enter Movie Details");
        setTitle("Movie App Login");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        ///input text boxes
        JPanel panel = new JPanel(new GridLayout(18, 2));
        panel.add(new JLabel("Title:"));
        title = new JTextField();
        panel.add(title);
        
        panel.add(new JLabel("Director:"));
        director = new JTextField();
        panel.add(director);
        
        panel.add(new JLabel("Movie ID:"));
        movieid = new JTextField();
        panel.add(movieid);
        
        panel.add(new JLabel("Cast:"));
        cast = new JTextField();
        panel.add(cast);
        
        panel.add(new JLabel("MPA Rating:"));
        rating = new JTextField();
        panel.add(rating);
        
        panel.add(new JLabel("Customer Review(s):"));
        reviews = new JTextField();
        panel.add(reviews);
        
        panel.add(new JLabel("Summary:"));
        summary = new JTextField();
        panel.add(summary);
        
        panel.add(new JLabel("Runtime:"));
        runtime = new JTextField();
        panel.add(runtime);
        
        panel.add(new JLabel("Ticket Cost:"));
        price = new JTextField();
        panel.add(price);
        
        panel.add(new JLabel("Run Time:"));
        time = new JTextField();
        panel.add(time);
        
        
        
        
     // Make a panel to hold the showtime fields
        JPanel showtimePanel = new JPanel(new GridLayout(6, 2)); 
        showtimePanel.setVisible(false); // 🔥 hidden at first

        showtimePanel.add(new JLabel("A show times:"));
        ashowtimes = new JTextField();
        showtimePanel.add(ashowtimes);

        showtimePanel.add(new JLabel("Lubbock show times:"));
        lshowtimes = new JTextField();
        showtimePanel.add(lshowtimes);

        showtimePanel.add(new JLabel("Levelland show times:"));
        leashowtimes = new JTextField();
        showtimePanel.add(leashowtimes);

        showtimePanel.add(new JLabel("Plainview show times:"));
        pshowtimes = new JTextField();
        showtimePanel.add(pshowtimes);

        showtimePanel.add(new JLabel("Snyder show times:"));
        sshowtimes = new JTextField();
        showtimePanel.add(sshowtimes);

        showtimePanel.add(new JLabel("Abilene show times:"));
        abshowtimes = new JTextField();
        showtimePanel.add(abshowtimes);

        // Now add the checkbox
        JCheckBox checkbox = new JCheckBox("Is this movie currently playing?");
        checkbox.addActionListener(e -> {
            current = checkbox.isSelected();
            showtimePanel.setVisible(current); // show/hide the fields when clicked
        });

        // Add everything to the main panel
        panel.add(checkbox);
        showtimePanel.add(new JLabel("Please enter showtimes for each location separated by ','"));
        panel.add(showtimePanel); // this is added but invisible until checkbox is checked

        
        
        add(panel, BorderLayout.CENTER);
        setVisible(true);
        
       
        
        //add panel and bottoms
        JPanel bottomPanel = new JPanel();
        JButton Home = new JButton("Home");
        JButton addmovie = new JButton("Add  Movie");
        
        //event handler
        Home.addActionListener(e ->  {new BrowseMenu(account, null); dispose();});
        addmovie.addActionListener(e -> {addmovie();dispose();new adminpage(account); });

        //bottom panel buttons
        bottomPanel.add(Home);
        bottomPanel.add(addmovie);
        

        add(bottomPanel, BorderLayout.SOUTH);
        setVisible(true);

            
        }
    private void addmovie() { // creates movie
        String titlef = title.getText();
        String directorf = director.getText();
        String castf = cast.getText();
        String ratingf = rating.getText();
        String summaryf = summary.getText();
        float reviewsf = getFloat(reviews);
        String runtimef = runtime.getText();
        int movieidf = getInt(movieid);
        float costf = getFloat(price);
        String timef = time.getText();
        String ashowtimesf = ashowtimes.getText();
        String lshowtimesf = lshowtimes.getText();
        String leashowtimesf = leashowtimes.getText();
        String pshowtimesf = pshowtimes.getText();
        String sshowtimesf = sshowtimes.getText();
        String abshowtimesf = abshowtimes.getText();

        boolean currentf = current;

        // Handle empty fields
        if (ashowtimesf.equals("")) {
            ashowtimesf = null;
        }
        if (lshowtimesf.equals("")) {
            lshowtimesf = null;
        }
        if (abshowtimesf.equals("")) {
            abshowtimesf = null;
        }
        if (leashowtimesf.equals("")) {
            leashowtimesf = null;
        }
        if (pshowtimesf.equals("")) {
            pshowtimesf = null;
        }
        if (sshowtimesf.equals("")) {
            sshowtimesf = null;
        }

        // ✅ Create the new Movie object
        Movie newMovie = new Movie(
            titlef, directorf, movieidf, reviewsf, costf, currentf,
            ashowtimesf, lshowtimesf, leashowtimesf, pshowtimesf, sshowtimesf, abshowtimesf
        );

        // ✅ Add the movie to the Database
        Database.movies.add(newMovie);

        // ✅ Save the movie to the file (this makes it permanent!)
        MovieStorage.saveMovie(newMovie);
    }


}


class comingSoon extends JFrame {
    protected JPanel moviePanel;

    public comingSoon(Account account, JFrame parent) {
        setTitle("Movies Coming Soon");
        setSize(500, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        moviePanel = new JPanel();
        moviePanel.setLayout(new BoxLayout(moviePanel, BoxLayout.Y_AXIS));
        JScrollPane scrollPane = new JScrollPane(moviePanel);
        add(scrollPane, BorderLayout.CENTER);

        // Load movies from the file
        List<Movie> allMovies = MovieStorage.loadMovies(); // Assuming this method exists and returns a list of movies.

        for (Movie m : allMovies) {
            if (!m.isCurrent()) { // Check if the movie is not currently playing
                JPanel mPanel = new JPanel();
                mPanel.setLayout(new BoxLayout(mPanel, BoxLayout.Y_AXIS));
                JButton mb = new JButton(m.toString());
                mPanel.add(mb);
                moviePanel.add(mPanel);
                mb.addActionListener(e -> {
                    dispose();
                    new moviePage(account, parent, m);
                });
            }
        }

        JButton backBtn = new JButton("Back");
        backBtn.addActionListener(e -> {
            dispose();
            parent.setVisible(true);
        });
        add(backBtn, BorderLayout.SOUTH);

        revalidate();
        repaint();
        setVisible(true);
    }
}


class moviePage extends JFrame {
    protected JPanel moviePanel;

    public moviePage(Account account, JFrame parent, Movie m) {
        setTitle("Movie Info");
        setSize(500, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        moviePanel = new JPanel();
        moviePanel.setLayout(new BoxLayout(moviePanel, BoxLayout.Y_AXIS));
        JScrollPane scrollPane = new JScrollPane(moviePanel);
        add(scrollPane, BorderLayout.CENTER);

        JTextArea movieInfoArea = new JTextArea(m.getMovieInfo());
        movieInfoArea.setEditable(false);
        moviePanel.add(movieInfoArea);

        if (m.current) {
            addShowtimesSection("Plainsview", m.pshowtimes, m, account);
            addShowtimesSection("Lubbock", m.lshowtimes, m, account);
            addShowtimesSection("Abiline", m.abshowtimes, m, account);
            addShowtimesSection("Snyder", m.sshowtimes, m, account);
            addShowtimesSection("Armarillo", m.ashowtimes, m, account);
            addShowtimesSection("Levalend", m.leashowtimes, m, account);
        }

        JButton backBtn = new JButton("Back");
        JButton checkout = new JButton("Check Out");

        backBtn.addActionListener(e -> {
            dispose();
            parent.setVisible(true);
        });

        JButton goToCartBtn = new JButton("View Cart");
        goToCartBtn.addActionListener(e -> {
            dispose();
            new CartScreen(account, this);  // Replace with your actual cart screen class
        });

        JPanel bottomPanel = new JPanel();
        bottomPanel.setLayout(new FlowLayout(FlowLayout.CENTER)); // Or BoxLayout if you want vertical stack
        bottomPanel.add(backBtn);
        bottomPanel.add(goToCartBtn);

        add(bottomPanel, BorderLayout.SOUTH);

        revalidate();
        repaint();
        setVisible(true);
    }

    private void addShowtimesSection(String location, String showtimes, Movie movie, Account account) {
        moviePanel.add(new JLabel("Showtimes at " + location + ":"));

        if (showtimes != null && !showtimes.trim().isEmpty()) {
            String[] times = showtimes.split(",");
            for (String time : times) {
                addShowtimeRow(moviePanel, account, movie, time.trim(), location);
            }
        } else {
            moviePanel.add(new JLabel("No showtimes available at " + location + "."));
        }
    }

    private void addShowtimeRow(JPanel container, Account account, Movie movie, String time, String location) {
        JPanel ticketPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));

        JLabel label = new JLabel(location + " - " + time + ": ");
        JSpinner spinner = new JSpinner(new SpinnerNumberModel(1, 1, 10, 1));
        JButton confirmBtn = new JButton("Add to Cart");

        confirmBtn.addActionListener(e -> {
            // Get the value from the JSpinner and cast to Integer
            int ticketCount = (Integer) spinner.getValue();  
            for (int i = 0; i < ticketCount; i++) {
                account.getCart().addToCart(movie, time, location, ticketCount);  // Pass ticketCount correctly
            }
            JOptionPane.showMessageDialog(this, ticketCount + " ticket(s) added to cart for " + time + " at " + location);
        });

        ticketPanel.add(label);
        ticketPanel.add(spinner);
        ticketPanel.add(confirmBtn);

        container.add(ticketPanel);
    }



    }




class paymentcomplete extends JFrame {
    protected JPanel moviePanel;

    public paymentcomplete(Account account, JFrame parent,Cart cart) {
        setTitle("Payment recived");
        setSize(500, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        moviePanel = new JPanel();
        moviePanel.setLayout(new BoxLayout(moviePanel, BoxLayout.Y_AXIS));
        JScrollPane scrollPane = new JScrollPane(moviePanel);
        add(scrollPane, BorderLayout.CENTER);

        
        
        JButton viewti = new JButton("View tickets");
        viewti.addActionListener(e -> {
        	account.addTicket(cart);
            dispose();
            new ticketscreen(account, parent);
        });
        
        JButton backBtn = new JButton("Return Home");
        backBtn.addActionListener(e -> {
        	account.addTicket(cart);
            dispose();
            new BrowseMenu(account, parent);
        });
        JPanel botpan = new JPanel();
        botpan.add(backBtn);
        botpan.add(viewti);

        add(botpan, BorderLayout.SOUTH);
        

        revalidate();
        repaint();
        setVisible(true);
    }
}

class ticketscreen extends JFrame {
    protected JPanel moviePanel;

    public ticketscreen(Account account, JFrame parent) {
        setTitle("Tickets Purchased");
        setSize(500, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        moviePanel = new JPanel();
        moviePanel.setLayout(new BoxLayout(moviePanel, BoxLayout.Y_AXIS));
        JScrollPane scrollPane = new JScrollPane(moviePanel);
        add(scrollPane, BorderLayout.CENTER);

        // Make sure tickets list is initialized
        if (account.tickets != null && !account.tickets.isEmpty()) {
            for (MovieTicket movie : account.tickets) {
                String text = movie + " Tickets";
                JButton movieb = new JButton(text);
                moviePanel.add(movieb);
            }
        } else {
            JLabel empty = new JLabel("No Recent Purchases");
            empty.setAlignmentX(Component.CENTER_ALIGNMENT); // Center it
            moviePanel.add(empty);
        }

        JButton backBtn = new JButton("Return Home");
        backBtn.addActionListener(e -> {
            dispose();
            new BrowseMenu(account, parent);
        });
        JPanel botpan = new JPanel();
        botpan.add(backBtn);
        add(botpan, BorderLayout.SOUTH);

        // FORCE layout refresh
        moviePanel.revalidate();
        moviePanel.repaint();
        revalidate();
        repaint();
        setVisible(true);
    }
}



