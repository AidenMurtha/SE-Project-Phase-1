package MBS;

import java.io.Serializable;

public class MovieTicket implements Serializable {
    
    private int movieId;
    private String movieTitle;
    private String showtime;
    private float quantity;
    Movie movie;


    // movie ticket constructor
    public MovieTicket(Movie movie, String showtime, String location, int quantity, float cost) {
        this.movie = movie;
        this.movieTitle = movie.getTitle(movie);
        this.showtime = showtime;
        this.quantity = quantity;
    }

    // Getters and Setters
    public int getMovieId() {return movieId;}

    public void setMovieId(int movieId) {this.movieId = movieId;}

    public String getMovieTitle() {return movieTitle;}

    public void setMovieTitle(String movieTitle) {this.movieTitle = movieTitle;}

    public String getShowtime() {return showtime;}

    public void setShowtime(String showtime) {this.showtime = showtime;}

    public float getQuantity() {return quantity;}

    public void setQuantity(int quantity) {this.quantity = quantity;}

}
