package MBS;

import java.io.Serializable;

public class MovieTicket implements Serializable {
    
    private int movieId;
    private String movieTitle;
    private String showtime;
    private float quantity;
    Movie movie;

    // Constructor for individual tickets
    public MovieTicket(int movieId, String movieTitle, String showtime, float quantity) {
        this.movieId = movieId;
        this.movieTitle = movieTitle;
        this.showtime = showtime;
        this.quantity = quantity;
    }

    // Constructor with Movie object
    public MovieTicket(Movie movie, String showtime, String location, int quantity, float cost) {
        this.movie = movie;
        this.movieTitle = movie.getTitle(movie);  // Assuming Movie class has getTitle() method
        this.showtime = showtime;
        this.quantity = quantity;
    }

    // Getters and Setters
    public int getMovieId() {
        return movieId;
    }

    public void setMovieId(int movieId) {
        this.movieId = movieId;
    }

    public String getMovieTitle() {
        return movieTitle;
    }

    public void setMovieTitle(String movieTitle) {
        this.movieTitle = movieTitle;
    }

    public String getShowtime() {
        return showtime;
    }

    public void setShowtime(String showtime) {
        this.showtime = showtime;
    }

    public float getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    // Override toString() to return movie title, showtime, and quantity
    @Override
    public String toString() {
        return movieTitle + " (" + quantity + " ticket(s)) at " + showtime;
    }
}
