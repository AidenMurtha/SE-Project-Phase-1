package MBS;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.io.IOException;

public class SignUpScreen extends JFrame {
    JTextField emailField, home, phone, name;
    JPasswordField passwordField;
    JFrame loginScreen;

    public SignUpScreen(JFrame loginScreen) {
        this.loginScreen = loginScreen;

        setTitle("Sign Up");
        setSize(400, 300);  
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel(new GridLayout(6, 2, 15, 15));  
        panel.setBorder(new EmptyBorder(30, 30, 30, 30));

        //create and add email field
        panel.add(new JLabel("New Email:"));
        emailField = new JTextField();
        emailField.setPreferredSize(new Dimension(250, 30)); 
        panel.add(emailField);

        //create and add password field
        panel.add(new JLabel("New Password:"));
        passwordField = new JPasswordField();
        passwordField.setPreferredSize(new Dimension(250, 30)); 
        panel.add(passwordField);

        //create and add name field
        panel.add(new JLabel("Name:"));
        name = new JTextField(); 
        name.setPreferredSize(new Dimension(250, 30)); 
        panel.add(name);

        //create and add home address field
        panel.add(new JLabel("Home Address:"));
        home = new JTextField();  
        home.setPreferredSize(new Dimension(250, 30));  
        panel.add(home);

        //create and add phone number field
        panel.add(new JLabel("Phone Number:"));
        phone = new JTextField();  
        phone.setPreferredSize(new Dimension(250, 30)); 
        panel.add(phone);

        // Create account button and action listener 
        JButton createBtn = new JButton("Create Account");
        createBtn.addActionListener(e -> createAccount());
        panel.add(createBtn);

        // Create back button and action listener 
        JButton backBtn = new JButton("Back to Login");
        backBtn.addActionListener(e -> backToLogin());
        panel.add(backBtn);

        //add panel and make it visible
        add(panel);
        setVisible(true);
    }

    private void createAccount() {
    	//get input from fields
        String emailf = emailField.getText();
        String passf = new String(passwordField.getPassword());
        String namef = name.getText();
        String homef = home.getText();
        String phonef = phone.getText();

        try {//check if user exists in database
            AccountStorage.loadAccounts();
        } catch (IOException | ClassNotFoundException e) {//Exception handler for error while reading file
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error loading accounts.");
            return;
        }
        //add account to database
        if (!Database.accounts.containsKey(emailf)) {
            Account newAccount = new Account(emailf, passf, "user", namef, homef, phonef);
            Database.accounts.put(emailf, newAccount);

            try {//add account to storage
                AccountStorage.saveAccounts();
                JOptionPane.showMessageDialog(this, "Account created successfully!");
                backToLogin(); // Go back to login after sign up
            } catch (IOException e) {
                e.printStackTrace();//if error saving account to file
                JOptionPane.showMessageDialog(this, "Error saving account.");
            }
        } else {//if account exits in database
            JOptionPane.showMessageDialog(this, "Account already exists.");
        }
    }
    //Return to login screen
    private void backToLogin() {
        setVisible(false);
        loginScreen.setVisible(true);
    }
}
