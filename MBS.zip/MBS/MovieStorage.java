package MBS;

import java.io.*;
import java.util.*;

public class MovieStorage {
	//file that stores all movies
    private static final String FILE_NAME = "movies.txt";

    // Save movie method
    public static void saveMovie(Movie movie) {//put movie info into file
        try (PrintWriter out = new PrintWriter(new FileWriter(FILE_NAME, true))) {
            out.println(movie.title + ";" + movie.director + ";" + movie.movieId + ";" + 
                        movie.avgReview + ";" + movie.cost + ";" + movie.current + ";" + 
                        movie.ashowtimes + ";" + movie.lshowtimes + ";" + 
                        movie.leashowtimes + ";" + movie.pshowtimes + ";" + 
                        movie.sshowtimes + ";" + movie.abshowtimes);
        } catch (IOException e) {//if saving movie info failed
            e.printStackTrace();
        }
    }

    // Load all movies
    public static List<Movie> loadMovies() {
        List<Movie> movies = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(FILE_NAME))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(";");
                if (parts.length >= 12) {  //each line should be 12 fields long
                	//save each part to its respective variable
                    String title = parts[0];
                    String director = parts[1];
                    int movieId = Integer.parseInt(parts[2]);
                    float avgReview = Float.parseFloat(parts[3]);
                    float cost = Float.parseFloat(parts[4]);
                    boolean current = Boolean.parseBoolean(parts[5]);
                    String ashowtimes = parts[6];
                    String lshowtimes = parts[7];
                    String leashowtimes = parts[8];
                    String pshowtimes = parts[9];
                    String sshowtimes = parts[10];
                    String abshowtimes = parts[11];
                    //create movie from its parts
                    Movie m = new Movie(title, director, movieId, avgReview, cost, current,
                                        ashowtimes, lshowtimes, leashowtimes, pshowtimes, sshowtimes, abshowtimes);
                    movies.add(m);
                }
            }
        } catch (IOException e) {//if file reading fails
            e.printStackTrace();
        }
        return movies;
    }
}
