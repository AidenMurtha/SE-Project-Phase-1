package MBS;

import javax.swing.*;
import javax.swing.border.EmptyBorder;

import java.awt.*;
import java.io.IOException;

public class LoginScreen extends JFrame {
    JTextField emailField;
    JPasswordField passwordField;

    public LoginScreen() {
        setTitle("Login");
        setSize(300, 200);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel(new GridLayout(3, 2, 10, 10));
        panel.setBorder(new EmptyBorder(15, 15, 15, 15));

        panel.add(new JLabel("Email:"));
        emailField = new JTextField();
        panel.add(emailField);

        panel.add(new JLabel("Password:"));
        passwordField = new JPasswordField();
        panel.add(passwordField);

        JButton loginBtn = new JButton("Login");
        loginBtn.addActionListener(e -> login());
        panel.add(loginBtn);

        JButton signupBtn = new JButton("Sign Up");
        signupBtn.addActionListener(e -> signup());
        panel.add(signupBtn);

        add(panel);
        setVisible(true);
    }

    // Login method that checks user credentials
    private void login() {
        String email = emailField.getText();
        String pass = new String(passwordField.getPassword());

        // Load accounts from file
        try {
            AccountStorage.loadAccounts();
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error loading accounts. Please try again.");
        }

        Account user = Database.accounts.get(email);
        if (user != null && user.password.equals(pass)) {
            setVisible(false);
            new BrowseMenu(user, this);
        } else {
            JOptionPane.showMessageDialog(this, "Invalid login.");
        }
    }

    // Sign-up method that creates a new account
    private void signup() {
        String email = emailField.getText();
        String pass = new String(passwordField.getPassword());

        // Load accounts from file
        try {
            AccountStorage.loadAccounts();
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error loading accounts. Please try again.");
        }

        // Check if the account already exists
        if (!Database.accounts.containsKey(email)) {
            Account newAccount = new Account(email, pass);
            Database.accounts.put(email, newAccount);

            // Save the new account to the file
            try {
                AccountStorage.saveAccounts();
            } catch (IOException e) {
                e.printStackTrace();
                JOptionPane.showMessageDialog(this, "Error saving the new account.");
            }

            JOptionPane.showMessageDialog(this, "Account created. You can now login.");
        } else {
            JOptionPane.showMessageDialog(this, "Account already exists.");
        }
    }
}
