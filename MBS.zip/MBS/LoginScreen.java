package MBS;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;

public class LoginScreen extends JFrame {
    JTextField emailField;
    JPasswordField passwordField;

    public LoginScreen() {
    	//create window
        setTitle("Login");
        setSize(300, 200);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        JPanel panel = new JPanel(new GridLayout(3, 2, 10, 10));
        panel.setBorder(new EmptyBorder(15, 15, 15, 15));

        //create input fields and add them to window
        panel.add(new JLabel("Email:"));
        emailField = new JTextField();
        panel.add(emailField);

        panel.add(new JLabel("Password:"));
        passwordField = new JPasswordField();
        panel.add(passwordField);

        //create buttons and event listener
        JButton loginBtn = new JButton("Login");
        loginBtn.addActionListener(e -> login());
        panel.add(loginBtn);

        JButton signupBtn = new JButton("Sign Up");
        signupBtn.addActionListener(e -> openSignUpScreen());
        panel.add(signupBtn);

        //add panel to window and make visible
        add(panel);
        setVisible(true);
    }

    private void login() {
    	//get login info
        String email = emailField.getText();
        String pass = new String(passwordField.getPassword());

        try {
            AccountStorage.loadAccounts();//load account
        } catch (Exception e) {//Exception for it there is a problem loading account
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error loading accounts.");
            return;
        }

        Account user = Database.accounts.get(email);
        if (user != null && user.password.equals(pass)) {//if user login is valid
            setVisible(false);
            new BrowseMenu(user, this);
            }else {//if user login i'snt valid
            	JOptionPane.showMessageDialog(this, "Invalid login.");
            }
        }
    


    private void openSignUpScreen() {
        dispose();//close current window
        new SignUpScreen(this); // Open the new signup window
    }
}
