package MBS;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class Account implements Serializable {
    private static final long serialVersionUID = 1L;  

    String email, password, location,address,name;
    int id;
    String phone;
    List<MovieTicket> tickets;
    int quantity;
    String type; 

    //account constructor
    public Account(String email, String password, String name, String type, String address, String phone) {
        tickets = new ArrayList<>();
        this.email = email;
        this.password = password;
        this.name = name;
        this.type = type; 
        this.address = address;
        this.phone = phone; 
    }

    
  //get and set functions
    public Cart getCart() {return Database.carts.computeIfAbsent(email, k -> new Cart(email));}

    public void addTicket(Cart cart) {
        for (MovieTicket ticket : cart.items) {
            tickets.add(ticket);
        }
    }

    public List<MovieTicket> getTickets() {return tickets;}
    
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String getPassword() { return password; }
    public void setPassword(String password) { this.password = password; }

    public String getLocation() { return location; }
    public void setLocation(String location) { this.location = location; }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getPhone() { return phone; }
    public void setPhone(String phone) { this.phone = phone; }

    public int getQuantity() { return quantity; }
    public void setQuantity(int quantity) { this.quantity = quantity; }

    public String getType() { return type; } 
    public void setType(String type) { this.type = type; }

}
