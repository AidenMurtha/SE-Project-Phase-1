package MBS;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class Account implements Serializable {
    private static final long serialVersionUID = 1L;  // Unique identifier for serialization
    
    // Account fields
    String email;

	 String password;

	 String location;
     int id;
     String phone;
    List<MovieTicket> tickets;
     int quantity;

    // Constructor
    public Account(String email, String password) {
        this.email = email;
        this.password = password;
        this.id = new Random().nextInt(10000); // Assign random ID
        this.location = "";  // Default empty value
        this.phone = "";     // Default empty value
        this.quantity = 0;   // Default value
        this.tickets = new ArrayList<>();  // Initialize the list of tickets
    }

    // Get the user's cart (if it exists in the database)
    public Cart getCart() {
        return Database.carts.computeIfAbsent(email, k -> new Cart(email));
    }

    // Add tickets from the cart to the user's ticket list
    public void addTicket(Cart cart) {
        for (MovieTicket ticket : cart.items) {
            tickets.add(ticket);  // Add each ticket from the cart
        }
    }

    // Get a list of tickets the user has
    public List<MovieTicket> getTickets() {
        return tickets;
    }

    // Getters and Setters
    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    @Override
    public String toString() {
        return "Account{" + "email='" + email + '\'' + ", id=" + id + ", phone='" + phone + '\'' + '}';
    }

    // Save account data to file (serialization)
    public void saveToFile() {
        try (ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream("account_" + email + ".ser"))) {
            out.writeObject(this);  // Write the account object to the file
            System.out.println("Account data saved successfully.");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Load account data from file (deserialization)
    public static Account loadFromFile(String email) {
        File file = new File("account_" + email + ".ser");
        if (!file.exists()) {
            System.out.println("No saved account found for email: " + email);
            return null;  // Return null if no saved data exists for the given email
        }
        try (ObjectInputStream in = new ObjectInputStream(new FileInputStream(file))) {
            return (Account) in.readObject();  // Deserialize and return the Account object
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
            return null;
        }
    }
}
