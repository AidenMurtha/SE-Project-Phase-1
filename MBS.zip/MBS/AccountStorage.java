package MBS;

import java.io.*;

public class AccountStorage {
	//set file name
    private static final String accounts = "accounts.dat";

    public static void loadAccounts() throws IOException, ClassNotFoundException {
        Database.accounts.clear();
        //create file
        File file = new File(accounts);

        // If the file exists and is not empty, load the accounts from it
        if (file.exists() && file.length() > 0) {
            try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(accounts))) {
                while (true) {
                    try {
                        // Read each account and put it in the database
                        Account account = (Account) ois.readObject();
                        Database.accounts.put(account.email, account);
                    } catch (EOFException e) {
                        break;  //stop reading at the end of file
                    }
                }
            }
        }


        if (!Database.accounts.containsKey("admin")) {
            // Create a new admin account if it does not exist
            Account adminAccount = new Account("admin", "admin123", "Admin", "admin", "Na", "Na");
            Database.accounts.put("admin", adminAccount);
            saveAccounts(); 
        }
    }

    public static void saveAccounts() throws IOException {
        // Save accounts to the file
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(accounts))) {
            for (Account account : Database.accounts.values()) {
                oos.writeObject(account);
            }
        }
    }
}
