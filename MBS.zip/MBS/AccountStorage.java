package MBS;

import java.io.*;
import java.util.HashMap;
import java.util.Map;

public class AccountStorage {

    private static final String accounts = "accounts.dat";

    public static void loadAccounts() throws IOException, ClassNotFoundException {
        // Ensure Database.accounts is empty before loading new data
        Database.accounts.clear();

        // Read from the file and load the accounts into the Database
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(accounts))) {
            while (true) {
                try {
                    // Read each account object and add it to the Database
                    Account account = (Account) ois.readObject();
                    Database.accounts.put(account.email, account);
                } catch (EOFException e) {
                    // End of file reached, exit the loop
                    break;
                }
            }
        }
    }

    public static void saveAccounts() throws IOException {
        // Write all accounts to the file
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(accounts))) {
            for (Account account : Database.accounts.values()) {
                oos.writeObject(account);
            }
        }
    }
}


