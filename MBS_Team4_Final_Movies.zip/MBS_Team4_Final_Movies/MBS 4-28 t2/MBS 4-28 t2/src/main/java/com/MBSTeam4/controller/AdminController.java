package com.MBSTeam4.controller;

import com.MBSTeam4.model.Database;
import com.MBSTeam4.model.Movie;
import com.MBSTeam4.model.Payment;
import com.MBSTeam4.model.Ticket;

import jakarta.servlet.http.HttpSession;
import org.springframework.ui.Model;

import java.util.*;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/admin")
public class AdminController {
	@GetMapping("/home")
	public String homePage(Model model, HttpSession session, @RequestParam(defaultValue = "All Locations") String selectedLocation) {
		String adminId = (String) session.getAttribute("adminId");
		
		if (adminId == null) {
	        return "redirect:/home";
	    } 
		
        model.addAttribute("username", adminId);
        model.addAttribute("movies", Database.movies);
        model.addAttribute("locations", Database.locations);
        model.addAttribute("accounts", Database.accounts.values());
        model.addAttribute("selectedLocation", selectedLocation);
        
        List<Map<String, Object>> allTickets = new ArrayList<>();
        for (Map.Entry<String, List<Ticket>> entry : Database.tickets.entrySet()) {
            String userId = entry.getKey();
            for (Ticket ticket : entry.getValue()) {
                Map<String, Object> ticketMap = new HashMap<>();
                ticketMap.put("userId", userId);
                ticketMap.put("ticket", ticket);
                for (Movie movie : Database.movies) {
                    if (movie.getMovieId() == ticket.getMovieId()) {
                        ticketMap.put("movie", movie);
                        break;
                    }
                }
                allTickets.add(ticketMap);
            }
        }
        model.addAttribute("allTickets", allTickets);
        
        List<Payment> filteredPayments = new ArrayList<>();
        for (Payment p : Database.payments) {
            if (selectedLocation.equals("All Locations") || p.getLocation().equals(selectedLocation)) {
                filteredPayments.add(p);
            }
        }

        List<Map<String, Object>> statistics = new ArrayList<>();
        float totalRevenue = 0f;

        Map<Integer, Map<String, Object>> grouped = new LinkedHashMap<>();
        for (Payment p : filteredPayments) {
            int key = p.getMovieId();  
            if (!grouped.containsKey(key)) {
                Map<String, Object> map = new HashMap<>();
                map.put("title", p.getMovieTitle());
                map.put("location", p.getLocation());
                map.put("showtime", p.getShowtime());
                map.put("sold", p.getSoldCount());
                map.put("revenue", p.getRevenue());
                grouped.put(key, map);
            } else {
                Map<String, Object> map = grouped.get(key);
                map.put("sold", (int) map.get("sold") + p.getSoldCount());
                map.put("revenue", (float) map.get("revenue") + p.getRevenue());
            }
            totalRevenue += p.getRevenue();
        }

        statistics.addAll(grouped.values());
        
        model.addAttribute("statistics", statistics);
        model.addAttribute("totalRevenue", totalRevenue);
        
        return "admin-home";
    }
	
	@PostMapping("/add-movie")
	public String addMovie(@RequestParam String title, 
						   @RequestParam String director,
	                       @RequestParam String showtime, 
	                       @RequestParam String location,
	                       @RequestParam String imgUrl,
	                       @RequestParam int movieId, 
	                       @RequestParam float avgReview, 
	                       @RequestParam float cost,
	                       @RequestParam String cast,
	                       @RequestParam String description,
	                       @RequestParam(required = false, defaultValue = "false") boolean current,
	                       Model model, HttpSession session) {

	    if (session.getAttribute("adminId") == null) {
	        return "redirect:/home";
	    }

	    Movie newMovie = new Movie(title, director, showtime, location, imgUrl, movieId, avgReview, cost);
	    newMovie.setCast(cast);
	    newMovie.setDescription(description);
	    newMovie.setStatus(current);
	    Database.movies.add(newMovie);
	    Database.saveMovies();

	    model.addAttribute("success", "Movie added successful");
	    return "redirect:/admin/home";
	}
	
	@PostMapping("/delete-movie")
	public String deleteMovie(@RequestParam int movieId, HttpSession session) {
	    if (session.getAttribute("adminId") == null) {
	        return "redirect:/home";
	    }
	    Database.movies.removeIf(movie -> movie.getMovieId() == movieId);
	    Database.saveMovies();
	    return "redirect:/admin/home";
	}
	
	@GetMapping("/edit-movie")
	public String showEditForm(@RequestParam int movieId, Model model, HttpSession session) {
	    if (session.getAttribute("adminId") == null) {
	        return "redirect:/home";
	    }
	    for (Movie movie : Database.movies) {
	        if (movie.getMovieId() == movieId) {
	            model.addAttribute("movie", movie);
	            return "edit-movie";
	        }
	    }
	    return "redirect:/admin/home";
	}
	
	@PostMapping("/edit-movie")
	public String editMovie(@RequestParam String title,
	                        @RequestParam String director,
	                        @RequestParam String showtime,
	                        @RequestParam String location,
	                        @RequestParam String imgUrl,
	                        @RequestParam int movieId,
	                        @RequestParam float avgReview,
	                        @RequestParam float cost,
	                        @RequestParam String cast,
		                       @RequestParam String description,
		                       @RequestParam(required = false, defaultValue = "false") boolean current,
	                        HttpSession session) {

	    if (session.getAttribute("adminId") == null) {
	        return "redirect:/home";
	    }

	    for (Movie movie : Database.movies) {
	        if (movie.getMovieId() == movieId) {
	            movie.setTitle(title);
	            movie.setDirector(director);
	            movie.setShowtime(showtime);
	            movie.setLocation(location);
	            movie.setImgUrl(imgUrl);
	            movie.setAvgReview(avgReview);
	            movie.setCost(cost);
	            movie.setCast(cast);
	    	    movie.setDescription(description);
	    	    movie.setStatus(current);
	    	    
	            break;
	        }
	    }
	    Database.saveMovies();
	    return "redirect:/admin/home";
	}
	
	@PostMapping("/save-all")
	public String saveAllMovies(@RequestParam List<Integer> movieIdList,
	                            @RequestParam List<String> titleList,
	                            @RequestParam List<String> directorList,
	                            @RequestParam List<String> showtimeList,
	                            @RequestParam List<String> locationList,
	                            @RequestParam List<String> imgUrlList,
	                            @RequestParam List<Float> avgReviewList,
	                            @RequestParam List<Float> costList,
	                            @RequestParam List<String> castList,
	                            @RequestParam List<String> descriptionList,
	                            @RequestParam(required = false) List<Boolean> currentList,
	                            HttpSession session) {
	    if (session.getAttribute("adminId") == null) {
	        return "redirect:/home";
	    }

	    for (int i = 0; i < movieIdList.size(); i++) {
	        for (Movie movie : Database.movies) {
	            if (movie.getMovieId() == movieIdList.get(i)) {
	                movie.setTitle(titleList.get(i));
	                movie.setDirector(directorList.get(i));
	                movie.setShowtime(showtimeList.get(i));
	                movie.setLocation(locationList.get(i));
	                movie.setImgUrl(imgUrlList.get(i));
	                movie.setAvgReview(avgReviewList.get(i));
	                movie.setCost(costList.get(i));
	                movie.setCast(castList.get(i));
	                movie.setDescription(descriptionList.get(i));
	                if (currentList != null && i < currentList.size()) {
	                    movie.setStatus(currentList.get(i));
	                } else {
	                    movie.setStatus(false);
	                }
	                break;
	            }
	        }
	    }

	    Database.saveMovies();
	    return "redirect:/admin/home";
	}

	
	@PostMapping("/delete-account")
	public String deleteAccount(@RequestParam String accountId, HttpSession session) {
	    if (session.getAttribute("adminId") == null) {
	        return "redirect:/home";
	    }

	    Database.accounts.remove(accountId);
	    Database.carts.remove(accountId); 
	    Database.saveAccounts();
	    Database.saveCarts();
	    
	    return "redirect:/admin/home";
	}
		
	@PostMapping("/invalidate-ticket")
	public String invalidateTicket(@RequestParam String userId,
	                               @RequestParam int ticketIndex,
	                               HttpSession session) {
	    if (session.getAttribute("adminId") == null) {
	        return "redirect:/home";
	    }

	    List<Ticket> userTickets = Database.tickets.get(userId);
	    if (userTickets != null && ticketIndex >= 0 && ticketIndex < userTickets.size()) {
	        Ticket ticket = userTickets.get(ticketIndex);
	        ticket.setValidity(false);
	        
	        Movie matched = null;
	        for (Movie m : Database.movies) {
	            if (m.getMovieId() == ticket.getMovieId()) {
	                matched = m;
	                break;
	            }
	        }
	        if (matched != null) {
	            Payment payment = new Payment();
	            payment.setMovieId(matched.getMovieId());
	            payment.setMovieTitle(matched.getTitle());
	            payment.setLocation(matched.getLocation());
	            payment.setShowtime(matched.getShowtime());
	            payment.setSoldCount(1);
	            payment.setRevenue(matched.getCost());
	            Database.payments.add(payment);
	            Database.savePayments();  
	        }
	        Database.saveTickets();
	    }
	    return "redirect:/admin/home";
	}
	
	@PostMapping("/delete-used-tickets")
	public String deleteUsedTickets(HttpSession session) {
	    if (session.getAttribute("adminId") == null) {
	        return "redirect:/home";
	    }

	    for (Map.Entry<String, List<Ticket>> entry : Database.tickets.entrySet()) {
	        List<Ticket> tickets = entry.getValue();
	        tickets.removeIf(ticket -> !ticket.getValidity()); 
	    }

	    Database.saveTickets();
	    return "redirect:/admin/home";
	}
	
	@PostMapping("/clear-payments")
	public String clearPayments(HttpSession session) {
	    if (session.getAttribute("adminId") == null) {
	        return "redirect:/home";
	    }

	    Database.payments.clear();
	    Database.savePayments();

	    return "redirect:/admin/home";
	}
}