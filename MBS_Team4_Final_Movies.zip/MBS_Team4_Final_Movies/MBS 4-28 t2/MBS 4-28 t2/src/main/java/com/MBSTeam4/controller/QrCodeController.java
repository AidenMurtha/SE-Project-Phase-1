package com.MBSTeam4.controller;

import com.MBSTeam4.model.Database;
import com.MBSTeam4.model.Movie;
import com.MBSTeam4.model.Ticket;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.qrcode.QRCodeWriter;
import com.google.zxing.client.j2se.MatrixToImageWriter;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.ResponseBody;

import java.io.ByteArrayOutputStream;
import java.util.List;

@Controller
public class QrCodeController {

    @GetMapping("/qrcode/{qrcode}")
    @ResponseBody
    public byte[] getQrImage(@PathVariable String qrcode) {
        try {
            System.out.println("Requested QR: " + qrcode);
            String[] parts = qrcode.split("_");
            if (parts.length < 4) {
                System.out.println("Invalid QR name format: " + qrcode);
                return null;
            }

            String userId = parts[1];
            int movieId = Integer.parseInt(parts[2]);
            Movie movie = findMovie(movieId);

            if (movie == null) {
                System.out.println("Movie not found for ID: " + movieId);
                return null;
            }

            Ticket matchedTicket = null;
            List<Ticket> allTickets = Database.tickets.get(userId);
            if (allTickets != null) {
                for (Ticket t : allTickets) {
                    if (t.getQrcode().equals(qrcode)) {
                        matchedTicket = t;
                        break;
                    }
                }
            }

            if (matchedTicket == null) {
                System.out.println("Ticket not found for QR: " + qrcode);
                return null;
            }

            String baseUrl = "http://10.161.101.227:8080/MBSTeam4/qr-code/";
            String qrText = baseUrl + qrcode;

            QRCodeWriter qrCodeWriter = new QRCodeWriter();
            BitMatrix bitMatrix = qrCodeWriter.encode(qrText, BarcodeFormat.QR_CODE, 1000, 1000);
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            MatrixToImageWriter.writeToStream(bitMatrix, "PNG", baos);
            return baos.toByteArray();

        } catch (Exception e) {
        	System.out.println(e.getMessage());
            return null;
        }
    }

    @GetMapping("/ticket-detail/{qrcode}")
    public String showQrDetail(@PathVariable String qrcode, Model model) {
        String[] parts = qrcode.split("_");
        if (parts.length < 4) {
            System.out.println("Invalid QR name format: " + qrcode);
            return "error"; 
        }

        String userId = parts[1];
        int movieId = Integer.parseInt(parts[2]);
        Movie movie = findMovie(movieId);

        if (movie == null) {
            System.out.println("Movie not found for ID: " + movieId);
            return "error";
        }

        Ticket matchedTicket = null;
        List<Ticket> allTickets = Database.tickets.get(userId);
        if (allTickets != null) {
            for (Ticket t : allTickets) {
                if (t.getQrcode().equals(qrcode)) {
                    matchedTicket = t;
                    break;
                }
            }
        }

        if (matchedTicket == null) {
            System.out.println("Ticket not found for QR: " + qrcode);
            return "error";
        }

        model.addAttribute("ticket", matchedTicket);
        model.addAttribute("movie", movie);
        return "qr-code"; 
    }


    private Movie findMovie(int movieId) {
        for (Movie m : Database.movies) {
            if (m.getMovieId() == movieId) {
                return m;
            }
        }
        return null;
    }
}
