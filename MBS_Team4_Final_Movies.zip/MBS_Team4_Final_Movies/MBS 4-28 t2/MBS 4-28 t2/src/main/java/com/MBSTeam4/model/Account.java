package com.MBSTeam4.model;
import java.io.Serializable;

public class Account implements Serializable {
	private static final long serialVersionUID = 1L;
	
	private String email;
    private String id;
    private String username;
    private String password;
    private String location;
    private long phone;
    
    public String getEmail() {
        return email;
    }

    public String getPassword() {
        return password;
    }
    
    public String getId() {
        return id;
    }
    
    public long getPhone() {
        return phone;
    }
    
    public String getUsername() {
        return username;
    }
    
    public String getLocation() {
        return location;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setPassword(String password) {
        this.password = password;
    }
    
    public void setId(String id) {
        this.id = id;
    }
    
    public void setPhone(long phonenumber) {
        this.phone = phonenumber;
    }

    public void setUsername(String username) {
        this.username = username;
    }
    
    public void setLocation(String location) {
        this.location = location;
    }
}
