package com.MBSTeam4.controller;

import com.MBSTeam4.model.Database;
import com.MBSTeam4.model.Movie;
import com.MBSTeam4.model.Account;
import com.MBSTeam4.model.Admin;
import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@Controller
public class HomeController {

	@GetMapping("/home")
	public String home(@RequestParam(required = false) String query,
			           @RequestParam(required = false) String selectedLocation,
			           Model model, HttpSession session) {
	    String userId = (String) session.getAttribute("userId");
	    String adminId = (String) session.getAttribute("adminId");
	    
	    if (adminId != null) {
	    	return "redirect:/admin/home";
	    } 
	    else if (userId != null) {
	    	return "redirect:/account/home";
	    } 
	    else {
	        model.addAttribute("username", "Guest");
	    }
	    
	    if (selectedLocation == null || selectedLocation.trim().isEmpty()) {
	    	selectedLocation = "All Locations";
	    }
	    
	    model.addAttribute("selectedLocation", selectedLocation); 
	    model.addAttribute("locations", Database.locations);
	    
	    //This part is for the search bar logic
	    if (query != null && !query.trim().isEmpty()) {
	        String lowerQuery = query.toLowerCase();
	        List<Movie> filtered = new ArrayList<>();

	        for (Movie movie : Database.movies) {
	            if (selectedLocation.equals("All Locations") || movie.getLocation().equals(selectedLocation) 
	            	&& movie.getTitle().toLowerCase().contains(lowerQuery)) {
	                filtered.add(movie);
	            }
	        }

	        for (int i = 0; i < filtered.size(); i++) {
	            for (int j = i + 1; j < filtered.size(); j++) {
	                Movie m1 = filtered.get(i);
	                Movie m2 = filtered.get(j);
	                int score1 = similarityScore(m1.getTitle(), lowerQuery);
	                int score2 = similarityScore(m2.getTitle(), lowerQuery);
	                
	                if (score2 > score1) {
	                    Movie temp = filtered.get(i);
	                    filtered.set(i, filtered.get(j));
	                    filtered.set(j, temp);
	                }
	            }
	        }

	        model.addAttribute("movies", filtered);
	        model.addAttribute("query", query);
	    } 
	    else {
	        List<Movie> notFiltered = new ArrayList<>();
	        for (Movie movie : Database.movies) {
	            if (selectedLocation.equals("All Locations") || movie.getLocation().equals(selectedLocation)) {
	                notFiltered.add(movie);
	            }
	        }
	        model.addAttribute("movies", notFiltered);
	    }

	    return "home";
	}
	
	//This part checks the similarity of search result with the movie title
	private int similarityScore(String title, String query) {
	    title = title.toLowerCase();
	    int score = 0;
	    for (char c : query.toCharArray()) {
	        if (title.contains(String.valueOf(c))) score++;
	    }
	    return score;
	}
	
    @GetMapping("/login-form")
    public String loginForm(Model model) {
        model.addAttribute("username", "Guest");
        return "login";
    }

    @GetMapping("/signup-form")
    public String signupForm(Model model) {
        model.addAttribute("username", "Guest");
        model.addAttribute("locations", Database.locations);
        return "signup";
    }

    @PostMapping("/login")
    public String login(@RequestParam String id,
                        @RequestParam String password,
                        @RequestParam String role,
                        Model model,
                        HttpSession session) {
        if ("admin".equals(role)) {
            Admin admin = Database.admins.get(id);
            if (admin != null && admin.getPassword().equals(password)) {
                session.setAttribute("adminId", id);
                return "redirect:/admin/home";
            } 
            else {
                model.addAttribute("error", "Invalid admin credentials");
                return "login";
            }
        } 
        else {
            Account account = Database.accounts.get(id);
            if (account != null && account.getPassword().equals(password)) {
                session.setAttribute("userId", id);
                return "redirect:/account/home";
            } 
            else {
                model.addAttribute("error", "Invalid user credentials");
                return "login";
            }
        }
    }

    @PostMapping("/signup")
    public String signUp(@RequestParam String id,
                         @RequestParam String password,
                         @RequestParam String username,
                         @RequestParam String email,
                         @RequestParam String phone,
                         @RequestParam String location,
                         Model model) {

        if (Database.accounts.containsKey(id) || "admin".equalsIgnoreCase(id)) {
            model.addAttribute("error", "ID already exists");
            model.addAttribute("locations", Database.locations);
            return "signup";
        }

        if (!email.matches("^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+$")) {
            model.addAttribute("error", "Invalid email format");
            model.addAttribute("locations", Database.locations);
            return "signup";
        }

        long phonenumber;
        try {
        	String digits = phone.replaceAll("[^0-9]", "");
            phonenumber = Long.parseLong(digits);
        } catch (NumberFormatException e) {
            model.addAttribute("error", "Invalid phone number (Enter numbers)");
            model.addAttribute("locations", Database.locations);
            return "signup";
        }

        Account newAccount = new Account();
        newAccount.setId(id);
        newAccount.setPassword(password);
        newAccount.setUsername(username);
        newAccount.setEmail(email);
        newAccount.setPhone(phonenumber);
        newAccount.setLocation(location);

        Database.accounts.put(id, newAccount);
        Database.saveAccounts();

        model.addAttribute("success", "Sign-up Successful");
        return "signup";
    }

    @GetMapping("/logout")
    public String logout(HttpSession session) {
        session.invalidate();
        return "redirect:/home";
    }
}
