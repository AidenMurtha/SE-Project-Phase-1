package com.MBSTeam4.model;

public class CreditCard extends Payment {
	
	private static final long serialVersionUID = 1L;
	private int cardNumber;
	private int securityCode;
	private int expDate;
	
	public int getCardNumber() {
    	return cardNumber;
    }
    
	public int getSecurityCode() {
    	return securityCode;
    }
	
	public int getExpDate() {
    	return expDate;
    }
	
    public void setCardNumber(int cardNumber) {
        this.cardNumber = cardNumber;
    }
    
    public void setSecurityCode(int code) {
        this.securityCode = code;
    }
    
    public void setExpDate(int date) {
        this.expDate = date;
    }
}
