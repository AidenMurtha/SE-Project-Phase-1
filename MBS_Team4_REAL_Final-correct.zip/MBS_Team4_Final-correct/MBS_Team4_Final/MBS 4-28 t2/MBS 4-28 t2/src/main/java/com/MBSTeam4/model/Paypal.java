package com.MBSTeam4.model;

public class Paypal extends Payment{
	
	private static final long serialVersionUID = 1L;
	private String paypalPassword;
	private String paypalEmail;
	
	public String getPaypalPassword() {
    	return paypalPassword;
    }
    
    public void setPaypalPassword(String password) {
        this.paypalPassword = password;
    }
    
    public String getPaypalEmail() {
    	return paypalEmail;
    }
    
    public void setPaypalEmail(String email) {
        this.paypalEmail = email;
    }
}
