package com.MBSTeam4.model;

import java.io.Serializable;

public class Ticket implements Serializable {
	private static final long serialVersionUID = 1L;
	
	private int movieId;
	private String qrcode;
	private boolean validity;
	private String accountId;
	
	public String getQrcode() {
        return qrcode;
    }
    
    public String getAccountId() {
        return accountId;
    }
    
    public boolean getValidity() {
        return validity;
    }
	
    public void setQrcode(String code) {
        this.qrcode = code;
    }
    
    public void setValidity(boolean validity) {
        this.validity = validity;
    }
    
    public void setAccountId(String id) {
        this.accountId = id;
    }

	public int getMovieId() {
		return movieId;
	}

	public void setMovieId(int movieId) {
		this.movieId = movieId;
	}
}
