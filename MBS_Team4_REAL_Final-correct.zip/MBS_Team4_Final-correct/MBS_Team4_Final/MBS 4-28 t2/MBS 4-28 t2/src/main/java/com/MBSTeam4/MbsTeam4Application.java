package com.MBSTeam4;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MbsTeam4Application {

	public static void main(String[] args) {
		SpringApplication.run(MbsTeam4Application.class, args);
	}

}
