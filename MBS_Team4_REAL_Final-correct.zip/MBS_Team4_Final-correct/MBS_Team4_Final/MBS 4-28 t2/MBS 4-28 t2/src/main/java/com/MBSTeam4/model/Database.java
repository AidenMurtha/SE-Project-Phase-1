package com.MBSTeam4.model;

import java.util.HashMap;
import java.util.Map;
import java.util.List;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

public class Database {
    
    public static Map<String, Account> accounts = new HashMap<>();
    public static Map<String, Cart> carts = new HashMap<>();
    public static Map<String, List<Ticket>> tickets = new HashMap<>();
    public static Map<String, Admin> admins = new HashMap<>();
    public static List<Movie> movies = new ArrayList<>();
    public static List<String> locations = new ArrayList<>();
    public static List<Payment> payments = new ArrayList<>();
    
    static {
        Admin admin = new Admin();
        admin.setId("admin");
        admin.setPassword("admin123"); 
        admins.put(admin.getId(), admin);
    }
        
    static {
        locations.add("Lubbock");
        locations.add("Amarillo");
        locations.add("Levelland");
        locations.add("Plainview");
        locations.add("Snyder");
        locations.add("Abilene");
    }
    
    static {
        loadAccounts();
        loadMovies();
        loadCarts();
        loadTickets();
        loadPayments();
    }
    
    public static void saveAccounts() {
        try {
            FileOutputStream fos = new FileOutputStream("accounts.dat");
            ObjectOutputStream oos = new ObjectOutputStream(fos);
            oos.writeObject(accounts);
            oos.close();
            fos.close();
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }
    }
    
    @SuppressWarnings("unchecked")
    public static void loadAccounts() {
        try {
            File file = new File("accounts.dat");
            if (file.exists()) {
                FileInputStream fis = new FileInputStream(file);
                ObjectInputStream ois = new ObjectInputStream(fis);
                accounts = (Map<String, Account>) ois.readObject();
                ois.close();
                fis.close();
            } else {
                accounts = new HashMap<>(); 
            }
        } catch (IOException | ClassNotFoundException e) {
        	System.out.println(e.getMessage());
        }
    }
    
    public static void saveMovies() {
        try {
            FileOutputStream fos = new FileOutputStream("movies.dat");
            ObjectOutputStream oos = new ObjectOutputStream(fos);
            oos.writeObject(movies);
            oos.close();
            fos.close();
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }
    }
    
    @SuppressWarnings("unchecked")
    public static void loadMovies() {
        try {
            File file = new File("movies.dat");
            if (file.exists()) {
                FileInputStream fis = new FileInputStream(file);
                ObjectInputStream ois = new ObjectInputStream(fis);
                movies = (List<Movie>) ois.readObject();
                ois.close();
                fis.close();
            } else {
                movies = new ArrayList<>();
            }
        } catch (IOException | ClassNotFoundException e) {
            System.out.println(e.getMessage());
        }
    }
    
    public static void saveCarts() {
        try {
            FileOutputStream fos = new FileOutputStream("carts.dat");
            ObjectOutputStream oos = new ObjectOutputStream(fos);
            oos.writeObject(carts);
            oos.close();
            fos.close();
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }
    }
    
    @SuppressWarnings("unchecked")
    public static void loadCarts() {
        try {
            File file = new File("carts.dat");
            if (file.exists()) {
                FileInputStream fis = new FileInputStream(file);
                ObjectInputStream ois = new ObjectInputStream(fis);
                carts = (Map<String, Cart>) ois.readObject();
                ois.close();
                fis.close();
            } else {
                carts = new HashMap<>(); 
            }
        } catch (IOException | ClassNotFoundException e) {
            System.out.println(e.getMessage());
        }
    }
    
    public static void saveTickets() {
        try {
            FileOutputStream fos = new FileOutputStream("tickets.dat");
            ObjectOutputStream oos = new ObjectOutputStream(fos);
            oos.writeObject(tickets);
            oos.close();
            fos.close();
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }
    }
    
    @SuppressWarnings("unchecked")
    public static void loadTickets() {
        try {
            File file = new File("tickets.dat");
            if (file.exists()) {
                FileInputStream fis = new FileInputStream(file);
                ObjectInputStream ois = new ObjectInputStream(fis);
                tickets = (Map<String, List<Ticket>>) ois.readObject();
                ois.close();
                fis.close();
            } else {
                tickets = new HashMap<>();
            }
        } catch (IOException | ClassNotFoundException e) {
            System.out.println(e.getMessage());
        }
    }
    
    public static void savePayments() {
        try {
            FileOutputStream fos = new FileOutputStream("payments.dat");
            ObjectOutputStream oos = new ObjectOutputStream(fos);
            oos.writeObject(payments);
            oos.close();
            fos.close();
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }
    }

    @SuppressWarnings("unchecked")
    public static void loadPayments() {
        try {
            File file = new File("payments.dat");
            if (file.exists()) {
                FileInputStream fis = new FileInputStream(file);
                ObjectInputStream ois = new ObjectInputStream(fis);
                payments = (List<Payment>) ois.readObject();
                ois.close();
                fis.close();
            } else {
                payments = new ArrayList<>();
            }
        } catch (IOException | ClassNotFoundException e) {
            System.out.println(e.getMessage());
        }
    }
}
