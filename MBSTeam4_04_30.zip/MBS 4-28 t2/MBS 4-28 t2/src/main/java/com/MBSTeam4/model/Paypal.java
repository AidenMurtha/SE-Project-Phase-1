package com.MBSTeam4.model;

public class Paypal extends Payment{
	private String paypalPassword;
	private String paypalId;
	
	public String getPaypalPassword() {
    	return paypalPassword;
    }
    
    public void setPaypalPassword(String password) {
        this.paypalPassword = password;
    }
    
    public String getPaypalId() {
    	return paypalId;
    }
    
    public void setPaypalId(String id) {
        this.paypalId = id;
    }
}
