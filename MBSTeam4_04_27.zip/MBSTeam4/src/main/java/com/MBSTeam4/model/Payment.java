package com.MBSTeam4.model;

public class Payment {
	private String transactionStatus;
	private String accountId;
	private String accountEmail;
	private String payMethod;
	private String fullName;
	private int zipcode;
	private float total;
	
	public String getTransactionStatus() {
        return transactionStatus;
    }
    
    public String getAccountId() {
        return accountId;
    }
    
    public String getAccountEmail() {
        return accountEmail;
    }
    
    public String getPayMethod() {
        return payMethod;
    }
	
    public float getTotal() {
    	return total;
    }
    
    public void setTransactionStatus(String status) {
        this.transactionStatus = status;
    }
    
    public void setAccountId(String id) {
        this.accountId = id;
    }
    
    public void setAccountEmail(String email) {
        this.accountEmail = email;
    }
    
    public void setPayMethod(String method) {
        this.payMethod = method;
    }
    
    public void setTotal(float total) {
        this.total = total;
    }
}
