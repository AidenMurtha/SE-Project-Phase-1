package com.MBSTeam4.controller;

import com.MBSTeam4.model.Database;
import com.MBSTeam4.model.Movie;
import com.MBSTeam4.model.Ticket;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.qrcode.QRCodeWriter;
import com.google.zxing.client.j2se.MatrixToImageWriter;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.ResponseBody;

import java.io.ByteArrayOutputStream;
import java.util.List;

@Controller
public class QrCodeController {

    @GetMapping("/qrcode/{qrcode}")
    @ResponseBody
    public byte[] getQrImage(@PathVariable String qrcode) {
        try {
            System.out.println("Requested QR: " + qrcode);
            String[] parts = qrcode.split("_");
            if (parts.length < 4) {
                System.out.println("Invalid QR name format: " + qrcode);
                return null;
            }

            String userId = parts[1];
            int movieId = Integer.parseInt(parts[2]);
            Movie movie = findMovie(movieId);

            if (movie == null) {
                System.out.println("Movie not found for ID: " + movieId);
                return null;
            }

            Ticket matchedTicket = null;
            List<Ticket> allTickets = Database.tickets.get(userId);
            if (allTickets != null) {
                for (Ticket t : allTickets) {
                    if (t.getQrcode().equals(qrcode)) {
                        matchedTicket = t;
                        break;
                    }
                }
            }

            if (matchedTicket == null) {
                System.out.println("Ticket not found for QR: " + qrcode);
                return null;
            }

            String qrText = "Title: " + movie.getTitle() +
                    "\nShowtime: " + movie.getShowtime() +
                    "\nLocation: " + movie.getLocation() +
                    "\nStatus: " + (matchedTicket.getValidity() ? "Unused" : "Used") +
                    "\nUser: " + userId;

            QRCodeWriter qrCodeWriter = new QRCodeWriter();
            BitMatrix bitMatrix = qrCodeWriter.encode(qrText, BarcodeFormat.QR_CODE, 500, 500);
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            MatrixToImageWriter.writeToStream(bitMatrix, "PNG", baos);
            return baos.toByteArray();

        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    private Movie findMovie(int movieId) {
        for (Movie m : Database.movies) {
            if (m.getMovieId() == movieId) {
                return m;
            }
        }
        return null;
    }
}
