package com.MBSTeam4.controller;

import com.MBSTeam4.model.Database;
import com.MBSTeam4.model.Movie;
import com.MBSTeam4.model.Ticket;

import jakarta.servlet.http.HttpSession;
import org.springframework.ui.Model;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.*;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/admin")
public class AdminController {

    @GetMapping("/home")
    public String homePage(Model model, HttpSession session) {
        String adminId = (String) session.getAttribute("adminId");

        if (adminId == null) {
            return "redirect:/home";
        } else {
            model.addAttribute("username", adminId);
            model.addAttribute("movies", Database.movies); // Ensure updated movie list is passed to the view
            model.addAttribute("locations", Database.locations);
            model.addAttribute("accounts", Database.accounts.values());
        }

        return "admin-home"; // Return the home page with the updated movie list
    }

    @PostMapping("/add-movie")
    public String addMovie(@RequestParam String title,
                           @RequestParam boolean current,
                           @RequestParam String director,
                           @RequestParam(required = false) String showtime,
                           @RequestParam(required = false) Float avgReview,
                           @RequestParam int movieId,
                           @RequestParam float cost,
                           @RequestParam String location,
                           @RequestParam String imgUrl,
                           @RequestParam String cast,
                           @RequestParam String description,
                           Model model, HttpSession session) {

        if (session.getAttribute("adminId") == null) {
            return "redirect:/home";
        }

        Movie newMovie;

        if (current) {
            if (showtime == null || showtime.isBlank()) showtime = "TBD";
            if (avgReview == null) avgReview = 0.0f;

            newMovie = new Movie(
                title, director, showtime, location, imgUrl, movieId,
                avgReview, cost, true, cast, description
            );
        } else {
            newMovie = new Movie(
                title, director, location, imgUrl, movieId,
                cost, false, cast, description
            );
        }

        // Debugging before adding movie
        System.out.println("Adding new movie: " + newMovie);

        // Add the movie to the database and save it
        Database.movies.add(newMovie);
        Database.saveMovies();

        // Debugging after saving movies
        System.out.println("Movies after adding: " + Database.movies);

        // Update the model with the latest list of movies
        model.addAttribute("movies", Database.movies);
        model.addAttribute("success", "Movie added successfully");
        return "redirect:/admin/home"; // Redirect to the home page
    }

    @PostMapping("/delete-movie")
    public String deleteMovie(@RequestParam int movieId, HttpSession session) {
        if (session.getAttribute("adminId") == null) {
            return "redirect:/home";
        }
        Database.movies.removeIf(movie -> movie.getMovieId() == movieId);
        Database.saveMovies();

        // Debugging after deleting the movie
        System.out.println("Movies after deletion: " + Database.movies);

        return "redirect:/admin/home";
    }

    @PostMapping("/delete-account")
    public String deleteAccount(@RequestParam String accountId, HttpSession session) {
        if (session.getAttribute("adminId") == null) {
            return "redirect:/home";
        }

        Database.accounts.remove(accountId);
        Database.carts.remove(accountId);
        Database.saveAccounts();
        Database.saveCarts();

        return "redirect:/admin/home";
    }

    @GetMapping("/all-tickets")
    public String viewAllTickets(Model model, HttpSession session) {
        if (session.getAttribute("adminId") == null) {
            return "redirect:/home";
        }

        List<Map<String, Object>> allTickets = new ArrayList<>();

        for (Map.Entry<String, List<Ticket>> entry : Database.tickets.entrySet()) {
            String userId = entry.getKey();
            for (Ticket ticket : entry.getValue()) {
                Map<String, Object> ticketMap = new HashMap<>();
                ticketMap.put("userId", userId);
                ticketMap.put("ticket", ticket);

                for (Movie movie : Database.movies) {
                    if (ticket.getQrcode().contains(String.valueOf(movie.getMovieId()))) {
                        ticketMap.put("movie", movie);
                        break;
                    }
                }

                allTickets.add(ticketMap);
            }
        }

        model.addAttribute("allTickets", allTickets);
        model.addAttribute("username", session.getAttribute("adminId"));
        return "admin-tickets";
    }

    @PostMapping("/invalidate-ticket")
    public String invalidateTicket(@RequestParam String userId, @RequestParam String qrcode, HttpSession session) {
        if (session.getAttribute("adminId") == null) {
            return "redirect:/home";
        }

        List<Ticket> userTickets = Database.tickets.get(userId);
        if (userTickets != null) {
            for (Ticket ticket : userTickets) {
                if (ticket.getQrcode().equals(qrcode)) {
                    ticket.setValidity(false);

                    File qrCodeFile = new File("src/main/resources/static/qrcodes/" + qrcode + ".png");
                    if (qrCodeFile.exists()) {
                        qrCodeFile.delete();
                    }
                    break;
                }
            }
            Database.saveTickets();
        }
        return "redirect:/admin/all-tickets";
    }

    @GetMapping("/edit-movie")
    public String getEditMoviePage(@RequestParam("movieId") int movieId, Model model) {
        Movie movieToEdit = null;
        for (Movie movie : Database.movies) {
            if (movie.getMovieId() == movieId) {
                movieToEdit = movie;
                break;
            }
        }

        if (movieToEdit != null) {
            model.addAttribute("movie", movieToEdit);
        } else {
            model.addAttribute("error", "Movie not found.");
        }

        return "edit-movie"; // This returns the page where the form is displayed
    }

    @PostMapping("/edit-movie")
    public String editMovie(@RequestParam String title,
                            @RequestParam String director,
                            @RequestParam String showtime,
                            @RequestParam String location,
                            @RequestParam String imgUrl,
                            @RequestParam int movieId,
                            @RequestParam float avgReview,
                            @RequestParam float cost,
                            @RequestParam boolean current, 
                            HttpSession session, Model model) {

        if (session.getAttribute("adminId") == null) {
            return "redirect:/home";
        }

        // Find and update the movie
        Movie movieToUpdate = null;
        for (Movie movie : Database.movies) {
            if (movie.getMovieId() == movieId) {
                movieToUpdate = movie;
                break;
            }
        }

        if (movieToUpdate != null) {
            // Update movie details
            movieToUpdate.setTitle(title);
            movieToUpdate.setDirector(director);
            movieToUpdate.setShowtime(showtime);
            movieToUpdate.setLocation(location);
            movieToUpdate.setImgUrl(imgUrl);
            movieToUpdate.setAvgReview(avgReview);
            movieToUpdate.setCost(cost);
            movieToUpdate.setCurrent(current);

            // Now that the movie is updated, call your saveMovies method to save the updated list
            Database.saveMovies();  // Use the method you already have to save the updated list of movies

            // Add a success message and update the model with the latest movie list
            model.addAttribute("movies", Database.movies);
            model.addAttribute("success", "Movie updated successfully");
            return "redirect:/admin/home"; // Redirect to the admin home page after saving
        } else {
            // Movie not found, show an error or return to the admin page
            model.addAttribute("error", "Movie not found.");
            return "redirect:/admin/home";
        }
    }

}
