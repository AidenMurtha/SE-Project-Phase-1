package com.MBSTeam4.model;

import java.io.Serializable;

public class Movie implements Serializable {
    private String title;
    private String director;
    private String showtime; // If the movie is currently playing, this might have a showtime
    private String location;
    private String imgUrl;
    private int movieId;
    private float avgReview;
    private float cost;
    private boolean current; // Whether the movie is currently showing
    private String cast;
    private String description;

    // Constructor for movies that are currently showing
    public Movie(String title, String director, String showtime, String location, String imgUrl,
                 int movieId, float avgReview, float cost, boolean current, String cast, String description) {
        this.title = title;
        this.director = director;
        this.showtime = showtime;
        this.location = location;
        this.imgUrl = imgUrl;
        this.movieId = movieId;
        this.avgReview = avgReview;
        this.cost = cost;
        this.current = current;
        this.cast = cast;
        this.description = description;
    }
    private static final long serialVersionUID = 5871565449025566893L;
    // Constructor for movies that are not currently showing
    public Movie(String title, String director, String location, String imgUrl,
                 int movieId, float cost, boolean current, String cast, String description) {
        this(title, director, "TBD", location, imgUrl, movieId, 0.0f, cost, current, cast, description);
    }

    // Getters and Setters
    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDirector() {
        return director;
    }

    public void setDirector(String director) {
        this.director = director;
    }

    public String getShowtime() {
        return showtime;
    }

    public void setShowtime(String showtime) {
        this.showtime = showtime;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getImgUrl() {
        return imgUrl;
    }

    public void setImgUrl(String imgUrl) {
        this.imgUrl = imgUrl;
    }

    public int getMovieId() {
        return movieId;
    }

    public void setMovieId(int movieId) {
        this.movieId = movieId;
    }

    public float getAvgReview() {
        return avgReview;
    }

    public void setAvgReview(float avgReview) {
        this.avgReview = avgReview;
    }

    public float getCost() {
        return cost;
    }

    public void setCost(float cost) {
        this.cost = cost;
    }

    public boolean isCurrent() {
        return current;
    }

    public void setCurrent(boolean current) {
        this.current = current;
    }

    public String getCast() {
        return cast;
    }

    public void setCast(String cast) {
        this.cast = cast;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
    @Override
    public String toString() {
        return "Movie{" +
                "title='" + title + '\'' +
                ", director='" + director + '\'' +
                ", showtime='" + showtime + '\'' +
                ", location='" + location + '\'' +
                ", movieId=" + movieId +
                ", avgReview=" + avgReview +
                ", cost=" + cost +
                ", current=" + current +
                ", cast='" + cast + '\'' +
                ", description='" + description + '\'' +
                '}';
    }
}

