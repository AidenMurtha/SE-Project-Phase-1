package com.MBSTeam4.model;

import java.io.Serializable;

public class Payment implements Serializable {
	private static final long serialVersionUID = 1L;
	
	private String movieTitle;
    private String location;
    private String showtime;
    private int movieId;
    private int soldCount;
    private float revenue;
    
	public String getMovieTitle() {
		return movieTitle;
	}
	
	public void setMovieTitle(String movieTitle) {
		this.movieTitle = movieTitle;
	}
	
	public String getLocation() {
		return location;
	}
	
	public void setLocation(String location) {
		this.location = location;
	}
	
	public String getShowtime() {
		return showtime;
	}
	
	public void setShowtime(String showtime) {
		this.showtime = showtime;
	}
	
	public int getSoldCount() {
		return soldCount;
	}
	
	public void setSoldCount(int soldCount) {
		this.soldCount = soldCount;
	}
	
	public float getRevenue() {
		return revenue;
	}
	
	public void setRevenue(float revenue) {
		this.revenue = revenue;
	}

	public int getMovieId() {
		return movieId;
	}

	public void setMovieId(int movieId) {
		this.movieId = movieId;
	}
}
    