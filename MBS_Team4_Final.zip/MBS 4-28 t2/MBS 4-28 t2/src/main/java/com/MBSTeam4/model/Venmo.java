package com.MBSTeam4.model;

public class Venmo extends Payment{
	
	private static final long serialVersionUID = 1L;
	private String venmoPassword;
	private String venmoId;
	
	public String getVenmoPassword() {
    	return venmoPassword;
    }
    
    public void setVenmoPassword(String password) {
        this.venmoPassword = password;
    }
    
    public String getVenmoId() {
    	return venmoId;
    }
    
    public void setVenmoId(String id) {
        this.venmoId = id;
    }
}
